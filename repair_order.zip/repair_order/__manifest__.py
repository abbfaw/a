# -*- coding: utf-8 -*-
{
    'name': "Repair Order",

    'summary': """
        Module de gestion de demande de reparation du Garage PAGANI
    """,

    'description': """
        Ordre de reparation PAGANI
    """,

    'author': "Akpagni Augustin, Amirou Diallo & Tano Martin",
    'website': "http://www.progistack.com",

    'category': 'Project Management',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': [
        'base',
        'mail',
        'fleet',
        'product',
        'stock',
        'sale',
        'account',
        'purchase',
        'hr',
        'portal',
        'permission_manager'
    ],

    # always loaded
    'data': [
        'security/ir.model.access.csv',
        'data/sequence.xml',
        'report/report.xml',
        'report/header_footer.xml',
        'report/template_repair_order.xml',
        'report/template_repairs.xml',
        'report/template_out_part.xml',
        'report/template_out_vehicle.xml',
        'report/template_sale_order.xml',
        'report/template_preview_sale_order.xml',
        'report/template_account_move.xml',
        'report/inherit_report_invoice.xml',
        'report/inherit_report_picking.xml',
        'report/inherit_report_purchasequotation.xml',
        'report/template_purchase_unecrypyed.xml',
        'wizard/wizard_repair_inventory.xml',
        'wizard/wizard_done_repairs.xml',
        'wizard/wizard_verify_parts.xml',
        'wizard/wizard_message_wizard.xml',
        'views/menu.xml',
        'views/view_fleet_vehicle.xml',
        'views/view_sale_order.xml',
        'views/view_purchase_order.xml',
        'views/view_product_pricelist.xml',
        'views/view_res_partner.xml',
        'views/view_account_move.xml',
        'views/view_res_user.xml',
        'views/view_stock_picking.xml',
        'views/view_repair_order.xml',
        'views/view_diagnostic.xml',
        'views/view_repairs.xml',
        'views/view_product_template.xml',
        'views/view_product_category.xml',
        # 'views/view_fact_sheet.xml',
        # 'views/view_config_order.xml',
    ],
    # only loaded in demonstration mode
    'demo': [
        'demo/demo.xml',
    ],

    'images': ['static/description/icon.png'],
    'sequence': -120,
    'application': True,
}
