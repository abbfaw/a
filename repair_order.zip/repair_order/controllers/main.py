# -*- coding: utf-8 -*-
from odoo import http
from odoo.http import request


class Main(http.Controller):

    @http.route('/repair_order/preview/quotation/<model("sale.order"):sale_id>/', website=True, auth='public')
    def preview_quotation(self, sale_id):
        data = {}
        data.setdefault('id_object', []).append(sale_id.id)
        for order in sale_id.order_line:
            if order.product_id.id:
                if order.product_id.categ_id.is_product:
                    taxe_name = ', '.join(map(lambda x: x.name, order.tax_id))
                    product = {
                        'id': order.product_id.categ_id.id,
                        'name': order.product_id.categ_id.name,
                        'quantity': 1.00,
                        'unite': order.product_uom,
                        'price_subtotal': order.price_subtotal,
                        'price_unit': order.price_subtotal,
                        'taxes': taxe_name,
                    }
                    data.setdefault('product', []).append(product)
                elif order.product_id.categ_id.is_workforce:
                    taxe_name = ', '.join(map(lambda x: x.name, order.tax_id))
                    product = {
                        'id': order.product_id.categ_id.id,
                        'name': order.product_id.categ_id.name,
                        'quantity': order.product_uom_qty,
                        'unite': order.product_uom,
                        'price_subtotal': order.price_subtotal,
                        'price_unit': order.price_unit,
                        'taxes': taxe_name,
                    }
                    data.setdefault('work_force', []).append(product)
                else:
                    taxe_name = ', '.join(map(lambda x: x.name, order.tax_id))
                    product = {
                        'id': order.product_id.categ_id.id,
                        'name': order.product_id.categ_id.name,
                        'quantity': order.product_uom_qty,
                        'unite': order.product_uom,
                        'price_subtotal': order.price_subtotal,
                        'price_unit': order.price_unit,
                        'taxes': taxe_name,
                    }
                    data.setdefault('other', []).append(product)

        list_product = {}
        final_product = []
        list_work = {}
        final_work = []

        if 'product' not in data:
            data['product'] = []
        else:
            for product in data['product']:
                name_product = product['name']
                if name_product in list_product:
                    list_product[name_product]['price_subtotal'] += product['price_subtotal']
                    list_product[name_product]['price_unit'] += product['price_unit']
                else:
                    list_product[name_product] = product

            for list_product_lines in list_product.items():
                final_product.append(list_product_lines[1])

            data['product'] = final_product

        if 'work_force' not in data:
            data['work_force'] = []
        else:
            for work in data['work_force']:
                name_product = work['name']
                if name_product in list_work:
                    list_work[name_product]['quantity'] += work['quantity']
                    list_work[name_product]['price_subtotal'] += work['price_subtotal']
                else:
                    list_work[name_product] = work

            for list_work_lines in list_work.items():
                final_work.append(list_work_lines[1])

            data['work_force'] = final_work

        if 'other' not in data:
            data['other'] = []

        docs = request.env['sale.order'].sudo().browse(data['id_object'][0])
        values = {
            'doc_model': 'sale.order',
            'docs': docs,
            'data': data
        }
        print('values =', values)
        return http.request.render('repair_order.report_preview_customer_quotation', values)
