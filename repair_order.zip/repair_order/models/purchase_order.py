# -*- coding: utf-8 -*-

from odoo import models, fields, api, _


class PurchaseOrder(models.Model):
    _inherit = "purchase.order"

    repair_order_id = fields.Many2one(
        'repair.order',
        string='Ordre de réparation',
        domain=[('state', 'not in', ['90_finished', '91_Vehicle_delivered', '92_cancel'])]
    )
    vehicle = fields.Char(string='Véhicule', compute='_compute_car_info', store=True)
    license_plate = fields.Char(string='Immatriculation', compute='_compute_car_info', store=True)
    chassis_vehicle = fields.Char(string='Numéro chassis', compute='_compute_car_info', store=True)
    year_car = fields.Char(string='Année', compute='_compute_car_info', store=True)
    employee_id = fields.Many2one('res.users', string='Demandeur', index=True, tracking=True, check_company=True)

    @api.depends('repair_order_id')
    def _compute_car_info(self):
        for rec in self:
            rec.vehicle = rec.vehicle = rec.repair_order_id.vehicle
            rec.license_plate = rec.repair_order_id.vehicle_id.license_plate
            rec.chassis_vehicle = rec.repair_order_id.chassis_number_car
            rec.year_car = rec.repair_order_id.vehicle_id.model_year

    def action_return_repair_order(self):
        self.ensure_one()
        return {
                'name': _('Ordre de réparation'),
                'view_type': 'form',
                'view_mode': 'kanban,tree,form',
                'res_model': 'repair.order',
                'view_id': False,
                'type': 'ir.actions.act_window',
                'domain': [('id', '=', self.repair_order_id.id)],
            }

    @api.model
    def create(self, vals):
        company_id = vals.get('company_id', self.default_get(['company_id'])['company_id'])
        # Ensures default picking type and currency are taken from the right company.
        self_comp = self.with_company(company_id)
        if vals.get('name', 'New') == 'New':
            seq_date = None
            if 'date_order' in vals:
                seq_date = fields.Datetime.context_timestamp(self, fields.Datetime.to_datetime(vals['date_order']))
            vals['name'] = self_comp.env['ir.sequence'].next_by_code('repairs.purchase', sequence_date=seq_date) or '/'
        vals, partner_vals = self._write_partner_values(vals)
        res = super(PurchaseOrder, self_comp).create(vals)
        if partner_vals:
            res.sudo().write(partner_vals)  # Because the purchase user doesn't have write on `res.partner`
        return res
