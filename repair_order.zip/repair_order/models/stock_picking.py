# -*- coding: utf-8 -*-

from odoo import models, fields, api, _


class StockPicking(models.Model):
    _inherit = "stock.picking"
    _order = "id desc"

    repair_order_id = fields.Many2one(
        'repair.order',
        string='Ordre de réparation',
        domain=[('state', 'not in', ['90_finished', '91_Vehicle_delivered', '92_cancel'])]
    )
    vehicle = fields.Char(string='Véhicule', compute='_compute_car_info', store=True)
    license_plate = fields.Char(string='Immatriculation', compute='_compute_car_info', store=True)
    chassis_vehicle = fields.Char(string='Numéro chassis', compute='_compute_car_info', store=True)

    @api.depends('repair_order_id')
    def _compute_car_info(self):
        for rec in self:
            rec.vehicle = rec.repair_order_id.vehicle
            rec.license_plate = rec.repair_order_id.vehicle_id.license_plate
            rec.chassis_vehicle = rec.repair_order_id.chassis_number_car

    @api.model_create_multi
    def create(self, vals_list):
        origin = [vals.get('origin') for vals in vals_list]
        if origin[0]:
            origin_name = origin[0]
            purchase = self.env['purchase.order'].sudo().search([('name', '=', origin_name)], limit=1, order='id desc')
            sale = self.env['sale.order'].sudo().search([('name', '=', origin_name)], limit=1, order='id desc')
            if purchase:
                vals_list[0]['repair_order_id'] = purchase.repair_order_id.id
            if sale:
                vals_list[0]['repair_order_id'] = sale.repair_order_id.id
        return super(StockPicking, self).create(vals_list)
