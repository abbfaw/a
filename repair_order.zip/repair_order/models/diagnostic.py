# -*- coding: utf-8 -*-

from odoo import models, fields, api, _
from odoo.exceptions import ValidationError


class Diagnostic(models.Model):
    _inherit = "repair.order"

    mechanical_workshop_ids = fields.One2many(
        comodel_name="detail.service", inverse_name="mechanical_id", string="Atelier mécanique", tracking=True)
    sheet_metal_workshop_ids = fields.One2many(
        comodel_name="detail.service", inverse_name="sheet_metal_id", string="Atelier parallélisme", tracking=True)
    paint_workshop_ids = fields.One2many(
        comodel_name="detail.service", inverse_name="paint_workshop_id", string="Atelier équilibrage", tracking=True)

    theorical_total = fields.Float(string='Total théorique', default=0.0, compute='_compute_theoretical_total',
                                   store=True)

    def action_create_purchase(self):
        for rec in self:
            purchase_vals = {
                'partner_id': 1,
                'state': 'draft',
                'repair_order_id': rec.id,
            }
        self.env['purchase.order'].sudo().create(purchase_vals)

    def create_cotation(self):
        price_list_express = self.env['product.pricelist'].sudo().search(
            [('is_pricelist_express', '=', True)], limit=1, order='id desc')
        price_list_public = self.env['product.pricelist'].sudo().search([('is_pricelist_express', '=', False)], limit=1,
                                                                        order='id desc')
        quote_vals = {
            'partner_id': self.client_id.id or False,
            'state': 'draft',
            'is_client_express': self.is_client_express,
            'pricelist_id': price_list_express.id if self.is_client_express else price_list_public.id,
            'repair_order_id': self.id,
            # 'vehicle': f"{self.mark_car} {self.model_car}",
            # 'license_plate': self.vehicle_id.license_plate,
            # 'chassis_vehicle': self.chassis_number_car,
        }
        amount_untaxed = 0.0

        list_products = {}
        list_services = {}
        list_forfait = {}

        order_id = self.env['sale.order'].sudo().create(quote_vals)
        for rec in self:
            for mechanical_workshop_line in rec.mechanical_workshop_ids:
                service_line_vals = {
                    'product_id': mechanical_workshop_line.article_id.id,
                    'name': mechanical_workshop_line.description if mechanical_workshop_line.description else mechanical_workshop_line.article_id.name,
                    'product_uom_qty': mechanical_workshop_line.quantity,
                    'order_id': order_id.id,
                }
                if not rec.is_client_express:
                    quote_vals['price_unit'] = mechanical_workshop_line.article_id.lst_price
                if mechanical_workshop_line.article_id.detailed_type == 'product':
                    id_product = service_line_vals['product_id']
                    if id_product in list_products:
                        list_products[id_product]['product_uom_qty'] += service_line_vals['product_uom_qty']
                    else:
                        list_products[id_product] = service_line_vals
                elif mechanical_workshop_line.article_id.categ_id.is_package:
                    id_forfait = service_line_vals['product_id']
                    if id_forfait in list_forfait:
                        list_forfait[id_forfait]['product_uom_qty'] += service_line_vals['product_uom_qty']
                    else:
                        list_forfait[id_forfait] = service_line_vals
                else:
                    id_service = service_line_vals['product_id']
                    if id_service in list_services:
                        list_services[id_service]['product_uom_qty'] += service_line_vals['product_uom_qty']
                    else:
                        list_services[id_service] = service_line_vals

            for sheet_metal_workshop_line in rec.sheet_metal_workshop_ids:
                service_line_vals = {
                    'product_id': sheet_metal_workshop_line.article_id.id,
                    'name': sheet_metal_workshop_line.description if sheet_metal_workshop_line.description else sheet_metal_workshop_line.article_id.name,
                    'product_uom_qty': sheet_metal_workshop_line.quantity,
                    'order_id': order_id.id,
                }
                if not rec.is_client_express:
                    quote_vals['price_unit'] = sheet_metal_workshop_line.article_id.lst_price
                if sheet_metal_workshop_line.article_id.detailed_type == 'product':
                    id_product = service_line_vals['product_id']
                    if id_product in list_products:
                        list_products[id_product]['product_uom_qty'] += service_line_vals['product_uom_qty']
                    else:
                        list_products[id_product] = service_line_vals
                elif sheet_metal_workshop_line.article_id.categ_id.is_package:
                    id_forfait = service_line_vals['product_id']
                    if id_forfait in list_forfait:
                        list_forfait[id_forfait]['product_uom_qty'] += service_line_vals['product_uom_qty']
                    else:
                        list_forfait[id_forfait] = service_line_vals
                else:
                    id_service = service_line_vals['product_id']
                    if id_service in list_services:
                        list_services[id_service]['product_uom_qty'] += service_line_vals['product_uom_qty']
                    else:
                        list_services[id_service] = service_line_vals

            for paint_workshop_line in rec.paint_workshop_ids:
                service_line_vals = {
                    'product_id': paint_workshop_line.article_id.id,
                    'name': paint_workshop_line.description if paint_workshop_line.description else paint_workshop_line.article_id.name,
                    'product_uom_qty': paint_workshop_line.quantity,
                    'order_id': order_id.id,
                }
                if not rec.is_client_express:
                    quote_vals['price_unit'] = paint_workshop_line.article_id.lst_price
                if paint_workshop_line.article_id.detailed_type == 'product':
                    id_product = service_line_vals['product_id']
                    if id_product in list_products:
                        list_products[id_product]['product_uom_qty'] += service_line_vals['product_uom_qty']
                    else:
                        list_products[id_product] = service_line_vals
                elif paint_workshop_line.article_id.categ_id.is_package:
                    id_forfait = service_line_vals['product_id']
                    if id_forfait in list_forfait:
                        list_forfait[id_forfait]['product_uom_qty'] += service_line_vals['product_uom_qty']
                    else:
                        list_forfait[id_forfait] = service_line_vals
                else:
                    id_service = service_line_vals['product_id']
                    if id_service in list_services:
                        list_services[id_service]['product_uom_qty'] += service_line_vals['product_uom_qty']
                    else:
                        list_services[id_service] = service_line_vals
            forfait_line_vals = {
                'name': 'Forfait',
                "display_type": "line_section",
                'order_id': order_id.id,
            }

            self.env['sale.order.line'].sudo().create(forfait_line_vals)
            if len(list_forfait) > 0:
                for list_forfait_line in list_forfait.items():
                    forfait_quantity_add = list_forfait_line[1]
                    self.env['sale.order.line'].sudo().create(forfait_quantity_add)
            if len(list_products) > 0:
                articles_line_vals = {
                    'name': 'Articles',
                    "display_type": "line_section",
                    'order_id': order_id.id,
                }
                self.env['sale.order.line'].sudo().create(articles_line_vals)
                for list_products_line in list_products.items():
                    product_quantity_add = list_products_line[1]
                    self.env['sale.order.line'].sudo().create(product_quantity_add)
            if len(list_services) > 0:
                services_line_vals = {
                    'name': 'Services',
                    "display_type": "line_section",
                    'order_id': order_id.id,
                }
                self.env['sale.order.line'].create(services_line_vals)
                for list_services_line in list_services.items():
                    service_quantity_add = list_services_line[1]
                    self.env['sale.order.line'].sudo().create(service_quantity_add)
            order_id.sudo().action_purchase_order()
            rec.state = '4_waiting_quotation'

    def change_diagnostic(self):
        for rec in self:
            value_mechanical = False
            value_bodywork = False
            value_painting = False
            if rec.service_mechanical:
                if rec.is_diagnostic_mechanical_finish:
                    value_mechanical = True
            else:
                value_mechanical = True
            if rec.service_bodywork:
                if rec.is_diagnostic_bodywork_finish:
                    value_bodywork = True
            else:
                value_bodywork = True
            if rec.service_painting:
                if rec.is_diagnostic_painting_finish:
                    value_painting = True
            else:
                value_painting = True
            if value_mechanical & value_bodywork & value_painting:
                rec.is_diagnostic_finish = True
                rec.create_cotation()

    def action_validate_diagnostic_mechanical(self):
        for rec in self:
            if len(rec.mechanical_workshop_ids) <= 0:
                raise ValidationError(
                    "Vous ne pouvez pas valider un diagnostic vide !")
            else:
                rec.is_diagnostic_mechanical_finish = True
        self.change_diagnostic()

    def action_validate_diagnostic_bodywork(self):
        for rec in self:
            if len(rec.sheet_metal_workshop_ids) <= 0:
                raise ValidationError(
                    "Vous ne pouvez pas valider un diagnostic vide !")
            else:
                rec.is_diagnostic_bodywork_finish = True
        self.change_diagnostic()

    def action_validate_diagnostic_painting(self):
        for rec in self:
            if len(rec.paint_workshop_ids) <= 0:
                raise ValidationError(
                    "Vous ne pouvez pas valider un diagnostic vide !")
            else:
                rec.is_diagnostic_painting_finish = True
        self.change_diagnostic()

    def action_validate_all_diagnostic(self):
        for rec in self:
            if len(rec.mechanical_workshop_ids) <= 0 and rec.service_mechanical:
                raise ValidationError(
                    "Vous ne pouvez pas valider un diagnostic vide !")
            elif len(rec.sheet_metal_workshop_ids) <= 0 and rec.service_bodywork:
                raise ValidationError(
                    "Vous ne pouvez pas valider un diagnostic vide !")
            elif len(rec.paint_workshop_ids) <= 0 and rec.service_painting:
                raise ValidationError(
                    "Vous ne pouvez pas valider un diagnostic vide !")
            else:
                rec.is_diagnostic_mechanical_finish = True
                rec.is_diagnostic_bodywork_finish = True
                rec.is_diagnostic_painting_finish = True
        self.change_diagnostic()

    def action_go_ready(self):
        for rec in self:
            list_product = self.action_check_availability()
            if len(list_product) == 0:
                rec.state = '7_ready'
            else:
                convert_message_to_string = '\n'.join([i for i in list_product])
                return {
                    'type': 'ir.actions.act_window',
                    'view_mode': 'form',
                    'view_type': 'form',
                    'readonly': False,
                    'name': 'Attention',
                    'res_model': 'verify.parts.wizard',
                    'target': 'new',
                    'context': {
                        "default_messages": convert_message_to_string
                    }
                }

    def action_check_availability(self):
        list_product_no_available = []
        for rec in self:
            for mechanical_workshop_line in rec.mechanical_workshop_ids:
                qty_necessary = mechanical_workshop_line.article_id.qty_available - mechanical_workshop_line.quantity

                if qty_necessary < 0 and mechanical_workshop_line.article_id.detailed_type == 'product':
                    message = '\t- Article : ' + mechanical_workshop_line.article_id.name + ' - quantité non disponible : ' + str(
                        abs(qty_necessary)) + ' ' + str(mechanical_workshop_line.unity_measure.name)
                    list_product_no_available.append(message)
            for sheet_metal_workshop_line in rec.sheet_metal_workshop_ids:
                qty_necessary = sheet_metal_workshop_line.article_id.qty_available - sheet_metal_workshop_line.quantity
                if qty_necessary and sheet_metal_workshop_line.article_id.detailed_type == 'product':
                    message = '\t- Article : ' + sheet_metal_workshop_line.article_id.name + ' - quantité non disponible : ' + str(
                        abs(qty_necessary)) + ' ' + str(sheet_metal_workshop_line.unity_measure.name)
                    list_product_no_available.append(message)
            for paint_workshop_line in rec.paint_workshop_ids:
                qty_necessary = paint_workshop_line.article_id.qty_available - paint_workshop_line.quantity
                if qty_necessary and paint_workshop_line.article_id.detailed_type == 'product':
                    message = '\t- Article : ' + paint_workshop_line.article_id.name + ' - quantité non disponible : ' + str(
                        abs(qty_necessary)) + ' ' + str(paint_workshop_line.unity_measure.name)
                    list_product_no_available.append(message)
            return list_product_no_available

    def action_submit_expertise(self):
        for rec in self:
            rec.state = '2_insurance'

    def action_create_other_quotation(self):
        self.create_cotation()
        for rec in self:
            rec.state = "4_waiting_quotation"

    @api.depends('mechanical_workshop_ids', 'sheet_metal_workshop_ids', 'paint_workshop_ids')
    def _compute_theoretical_total(self):
        total_theorical = 0.0
        for rec in self:
            for mechanical_line in rec.mechanical_workshop_ids:
                if mechanical_line.article_id.detailed_type == 'service':
                    total_theorical += mechanical_line.quantity
            for bodywork_line in rec.sheet_metal_workshop_ids:
                if bodywork_line.article_id.detailed_type == 'service':
                    total_theorical += bodywork_line.quantity
            for painting_line in rec.paint_workshop_ids:
                if painting_line.article_id.detailed_type == 'service':
                    total_theorical += painting_line.quantity
            rec.theorical_total = total_theorical


class DetailService(models.Model):
    _name = "detail.service"
    _description = "Détail de services"
    _inherit = ['mail.thread', 'mail.activity.mixin']

    mechanical_id = fields.Many2one(
        "repair.order", string="Mécanique", ondelete='cascade')
    sheet_metal_id = fields.Many2one(
        "repair.order", string="Tôlerie", ondelete='cascade')
    paint_workshop_id = fields.Many2one(
        "repair.order", string="Peinture", ondelete='cascade')
    article_id = fields.Many2one("product.product",
                                 string="Articles/Services", ondelete='cascade', required=True, tracking=True)
    description = fields.Char(string="description", tracking=True)
    quantity = fields.Float(string='Qté/Durée', default=0.0, required=True, digits="Product Unit Of Measure",
                            help="La quantité de produit nécessaire.", tracking=True)
    quantity_util = fields.Float(string='Qté utilisée/Durée', default=0.0, tracking=True)
    unity_measure = fields.Many2one('uom.uom', "Unité de mesure", related='article_id.uom_po_id', readonly=True)
