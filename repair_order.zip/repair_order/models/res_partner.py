# -*- coding: utf-8 -*-

from odoo import models, fields, api, _


class ResPartner(models.Model):
    _inherit = 'res.partner'

    is_assurance = fields.Boolean(default=False, string="Est une assurance")
    # repair_order_count = fields.Integer(string="Compte OR partenaire", compute='_compute_repair_order_count', store=True)
    repair_order_ids = fields.One2many('repair.order', 'client_id', string='Ordre de réparation', copy=False)
    vehicle_id = fields.One2many('fleet.vehicle', 'client_id', string='Véhicule', copy=False)
    email = fields.Char(string="email", default="@")

    def call_invoice(self):
        self._invoice_total()

    @api.onchange('is_company')
    def onchange_company_type_change(self):
        for rec in self:
            if not rec.is_company:
                rec.is_assurance = False

    # @api.depends('repair_order_ids')
    # def _compute_repair_order_count(self):
    #     for rec in self:
    #         rec.repair_order_count = len(rec.repair_order_ids)

    def action_view_repair_order(self):
        return {
            'name': _('Ordre de réparation'),
            'view_type': 'form',
            'view_mode': 'kanban,tree,form',
            'res_model': 'repair.order',
            'view_id': False,
            'type': 'ir.actions.act_window',
            'domain': [('client_id', '=', self.id)],
        }
