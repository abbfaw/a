# -*- coding: utf-8 -*-

import pytz
from datetime import datetime
from odoo import models, fields, api, _
from odoo.exceptions import ValidationError

FUEL_TYPES = [
    ('diesel', 'Diesel'),
    ('gasoline', 'Essence'),
    ('hybrid', 'Hybride Diesel'),
    ('full_hybrid_gasoline', 'Hybride Essense'),
    ('plug_in_hybrid_diesel', 'Hybride Diesel Rechargeable'),
    ('plug_in_hybrid_gasoline', 'Hybride Essense Rechargeable'),
    ('cng', 'CNG'),
    ('lpg', 'LPG'),
    ('hydrogen', 'Hydrogène'),
    ('electric', 'Electrique'),
]


class RepairOrder(models.Model):
    _name = 'repair.order'
    _description = 'Repair Order'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'priority, id desc'
    _rec_name = 'reference'

    @api.model
    def _default_time_utc(self):
        locale_time = datetime.now()
        dt_utc = locale_time.astimezone(pytz.UTC)
        return dt_utc

    # Information client
    reference = fields.Char(string='Référence', copy=False, readonly=True, index=True,
                            default=lambda self: _('Nouveau'))
    ratio_hour_repair = fields.Char(string="Ratio heure théorique/ heure réelle")
    # ratio_hour_number = fields.Float(string="Ratio en nombre pour faire order by")
    win_hour = fields.Float(string="Heures gagnées", default=0.0)
    client_id = fields.Many2one('res.partner', string='Client', tracking=True, required=True)
    client_phone = fields.Char(string='Téléphone', tracking=True, required=True)
    message_main_attachment_id = fields.Many2one(groups="hr.group_hr_user")
    client_mobile = fields.Char(string='Mobile', tracking=True)
    client_email = fields.Char(string='Email', tracking=True, required=True)
    intervention = fields.Text(string='Intervention', required=True, tracking=True)
    claim_number = fields.Char(string='Numéro de sinistre', tracking=True)
    date_of_accident = fields.Date(string="date de l'accident", tracking=True)
    count_repair = fields.Float(string="Nombres OR", readonly=True)
    insurance = fields.Selection([
        ('yes', 'Oui'),
        ('no', 'Non'),
    ], string="Prise en charge assurance", default="no", tracking=True)
    expertise = fields.Selection([
        ('yes', 'Oui'),
        ('no', 'Non'),
    ], string="Expertise", default="no", tracking=True)
    expertise_doc_ids = fields.Many2many(
        'ir.attachment',
        'expertise_doc_rel',
        string="Fiche d'expertise", tracking=True)
    repair_order_ids = fields.Many2many(
        comodel_name='ir.attachment',
        string='Bon de réparation')
    vip_customer = fields.Selection([
        ('yes', 'Oui'),
        ('no', 'Non'),
    ], string='Client VIP', default='no', tracking=True)
    is_client_express = fields.Boolean(default=False, string="Client express")
    priority = fields.Selection([
        ('0', 'Non urgent'),
        ('1', 'Normal'),
        ('2', 'Important'),
        ('3', 'Urgent')
    ], string="Priorité", tracking=True)
    receipt_date = fields.Datetime(string='Date de réception', default=fields.Datetime.now, tracking=True)
    technical_visit_date = fields.Date(string='Date de visite technique', tracking=True)

    service_mechanical = fields.Boolean(string="Mécanique", default=False, tracking=True)
    service_bodywork = fields.Boolean(string="Parallélisme", default=False, tracking=True)
    service_painting = fields.Boolean(string="Équilibrage", default=False, tracking=True)

    # Information véhicule
    vehicle_id = fields.Many2one('fleet.vehicle', string='Immatriculation', required=True, tracking=True)
    vehicle = fields.Char(string='Véhicule')
    chassis_number_car = fields.Char(string='Numéro de chassis')
    fuel_type_car = fields.Selection(FUEL_TYPES, string="Type de carburant")
    input_km_car = fields.Integer(string="Km entrés", required=True, tracking=True)
    output_km_car = fields.Integer(string="Km sortis", tracking=True)
    traveled_km_car = fields.Integer(string="Différence Km", compute='_get_traveled_km_car')
    images_car = fields.Many2many(
        'ir.attachment',
        'images_car_doc_rel',
        string="Photos véhicules", help="Ce sont les photos du véhicule", tracking=True
    )
    technical_file = fields.Many2many(
        'ir.attachment',
        'technical_file_doc_rel',
        string="Fiche technique", help="C'est la fiche technique", tracking=True
    )
    form_report = fields.Many2many(
        'ir.attachment',
        'form_report_doc_rel',
        string="Fiche constat", help="C'est la photo de la fiche constat", tracking=True
    )

    # Information constat
    cigarette_lighter = fields.Boolean(string="Allume cigare", tracking=True)
    radio = fields.Boolean(string="Radio", tracking=True)
    antenna = fields.Boolean(string="Antenne", tracking=True)
    toolkit = fields.Boolean(string="Trousse à outils", tracking=True)
    windshield_wiper = fields.Boolean(string="Essuie glaces", tracking=True)
    mirror = fields.Boolean(string="Rétroviseurs", tracking=True)
    hubcap = fields.Boolean(string="Enjoliveurs", tracking=True)
    cd_or_usb = fields.Boolean(string="CD ou clé USB", tracking=True)
    carbon_plug = fields.Boolean(string="Bouchon Carb.", tracking=True)
    jack = fields.Boolean(string="Cric", tracking=True)
    spare_tire = fields.Boolean(string="Roue de secours", tracking=True)
    level_fuel = fields.Selection([
        ('0_four', '4/4'),
        ('1_tree', '3/4'),
        ('2_two', '1/2'),
        ('3_one', '1/4'),
        ('4_zero', '0'),
    ], string="Niveau de carburant", default='0_four', tracking=True)
    note = fields.Text(string='Note', tracking=True)
    state = fields.Selection(selection=[
        ('0_draft', 'Brouillon'),
        ('1_received', 'Réceptionné'),
        ('2_insurance', 'Attente expertise'),
        ('3_in_diagnosis', 'En diagnostic'),
        ('4_waiting_quotation', 'Attente quotation'),
        ('5_waiting_customer_validation', 'Attente validation client'),
        ('6_waiting_parts', 'Attente pièces'),
        ('7_ready', 'Prêt'),
        ('8_in_progress', 'Travaux en cours'),
        ('90_finished', 'Terminé'),
        ('91_Vehicle_delivered', 'Véhicule livré'),
        ('92_cancel', 'Annulé'),
    ], string='Status', readonly=True, copy=False, tracking=True, default='0_draft')
    active = fields.Boolean(string="Active", default=True, tracking=True)

    # validate diagnostic
    is_diagnostic_mechanical_finish = fields.Boolean(default=False, copy=False)
    is_diagnostic_bodywork_finish = fields.Boolean(default=False, copy=False)
    is_diagnostic_painting_finish = fields.Boolean(default=False, copy=False)
    is_diagnostic_finish = fields.Boolean(default=False, copy=False)

    # pièces véhicules
    is_registration_card = fields.Boolean(default=False, string="Carte grise")
    is_sticker = fields.Boolean(default=False, string="Vignettes")
    is_insurance_vehicule_card = fields.Boolean(default=False, string="Pièces assurances véhicule")
    end_date_insurance = fields.Date(string="Date de fin d'assurance", default=fields.Datetime.now)

    # champs relationnels pour devis
    quotation_ids = fields.One2many('sale.order', 'repair_order_id', string='Devis', copy=False)
    quotation_count = fields.Integer(string="Compte cotations", compute='_compute_quotation_count', copy=False,
                                     default=0, store=True)

    # champs relationnels pour achat
    purchase_ids = fields.One2many('purchase.order', 'repair_order_id', string='Achat', copy=False)
    purchase_count = fields.Integer(string="Compte achat", compute='_compute_purchase_count', copy=False, default=0,
                                    store=True)

    # champs relationnels pour facture
    account_ids = fields.One2many('account.move', 'repair_order_id', string='Facture', copy=False)
    account_count = fields.Integer(string="Compte facture", compute='_compute_account_count', copy=False, default=0,
                                   store=True)

    # champs relationnels pour les entrées et sorties du stock
    stock_picking_ids = fields.One2many('stock.picking', 'repair_order_id', string='Stock', copy=False)
    stock_picking_in_count = fields.Integer(string="Compte picking in",
                                            compute='_compute_stock_picking_count', copy=False, default=0,
                                            store=True)
    stock_picking_out_count = fields.Integer(string="Compte picking out",
                                             compute='_compute_stock_picking_count', copy=False, default=0,
                                             store=True)

    fact_sheet_ids = fields.One2many('fact.sheet', 'repair_order_id', string='Constat', copy=False)

    # signature
    user_id = fields.Many2one(string="Responsable", comodel_name='res.users', default=lambda self: self.env.user,
                              readonly=True)
    name_client = fields.Char(related="client_id.name", readonly=True)
    date_signature_recept = fields.Datetime(string='Date signature réception', default=fields.Datetime.now)
    date_signature_customer = fields.Datetime(string='Date signature client', default=fields.Datetime.now)
    signature_reception = fields.Binary(string="Signature réception", tracking=True)
    signature_customer = fields.Binary(string="Signature client", tracking=True)

    workshop = fields.Char(string="Atelier concernés", compute="_compute_workshop", store=True)

    @api.depends('service_mechanical', 'service_bodywork', 'service_painting')
    def _compute_workshop(self):
        for rec in self:
            list_workshop = []
            if rec.service_mechanical:
                list_workshop.append('Mécanique')
            if rec.service_bodywork:
                list_workshop.append('Parallélisme')
            if rec.service_painting:
                list_workshop.append('Équilibrage')
            rec.workshop = ' - '.join([i for i in list_workshop])

    def confirm_signature(self):
        active_id = self._context.get('active_id')
        upd_var = self.env['repair.order']
        vals = {'signature_reception': self.signature_reception, 'signature_customer': self.signature_customer}
        upd_var.write(vals)
        return {'type': 'ir.actions.client', 'tag': 'reload'}

    def _get_product_lines(self):
        """Fonction permenttant de recuperer les transferts internes effectués pour l'afficher sur le report de sortie de pièces"""
        for rec in self:
            data = {}
            company = self.env.context['allowed_company_ids'][0]
            pick = self.env['stock.picking'].sudo().search([
                ('company_id', '=', company),
                ('repair_order_id', '=', rec.id),
                ('picking_type_code', '=', 'internal'),
                ('state', '=', 'done'),
            ])
            for line in pick.move_ids_without_package:
                prod = {
                    'id': line.product_id.id,
                    'name': line.product_id.name,
                    'quantity': line.quantity_done,
                    'uom': line.product_uom.name
                }
                data.setdefault('lines', []).append(prod)

            list_product = {}
            final_product = []

            if 'lines' not in data:
                data['lines'] = []
            else:
                for product in data['lines']:
                    name_product = product['name']
                    if name_product in list_product:
                        list_product[name_product]['quantity'] += product['quantity']
                    else:
                        list_product[name_product] = product

                for list_product_lines in list_product.items():
                    final_product.append(list_product_lines[1])

                data['lines'] = final_product
            return data

    @api.depends('output_km_car', 'input_km_car')
    def _get_traveled_km_car(self):
        for rec in self:
            if rec.output_km_car > 0:
                rec.traveled_km_car = rec.output_km_car - rec.input_km_car
            else:
                rec.traveled_km_car = rec.input_km_car

    @api.depends('quotation_ids')
    def _compute_quotation_count(self):
        for rec in self:
            rec.quotation_count = len(rec.quotation_ids.ids)

    @api.depends('purchase_ids')
    def _compute_purchase_count(self):
        for rec in self:
            rec.purchase_count = len(rec.purchase_ids.ids)

    @api.depends('account_ids')
    def _compute_account_count(self):
        for rec in self:
            rec.account_count = len(rec.account_ids.ids)

    @api.depends('stock_picking_ids')
    def _compute_stock_picking_count(self):
        for rec in self:
            company = self.env.user.company_id
            print('company', company)
            pick_in = self.env['stock.picking'].sudo().search([
                ('company_id', '=', company.id),
                ('repair_order_id', '=', rec.id),
                ('picking_type_code', '=', 'incoming'),
            ])
            pick_out = self.env['stock.picking'].sudo().search([
                ('company_id', '=', company.id),
                ('repair_order_id', '=', rec.id),
                ('picking_type_code', '!=', 'incoming'),
            ])
            rec.stock_picking_in_count = len(pick_in)
            rec.stock_picking_out_count = len(pick_out)

    @api.onchange('client_id')
    def onchange_partner_id(self):
        addr = {}
        if self.client_id:
            addr = self.client_id.address_get(['contact'])
            addr['client_phone'] = self.client_id.phone
            addr['client_mobile'] = self.client_id.mobile
            addr['client_email'] = self.client_id.email
        return {'value': addr}

    @api.onchange('vehicle_id')
    def onchange_vehicle_id(self):
        addr = {}
        if self.vehicle_id:
            addr['fuel_type_car'] = self.vehicle_id.fuel_type
            # addr['model_car'] = self.vehicle_id.model_id.name
            addr['vehicle'] = f"{self.vehicle_id.brand_id.name} {self.vehicle_id.model_id.name}".upper() if self.vehicle_id else ""
            # addr['mark_car'] = self.vehicle_id.brand_id.name
            addr['chassis_number_car'] = self.vehicle_id.vin_sn
            addr['input_km_car'] = self.vehicle_id.odometer
            addr['technical_visit_date'] = self.vehicle_id.technical_visit_date
        return {'value': addr}

    def action_view_purchase(self):
        return {
            'name': _('Achat'),
            'view_type': 'form',
            'view_mode': 'kanban,tree,form',
            'res_model': 'purchase.order',
            'view_id': False,
            'type': 'ir.actions.act_window',
            'domain': [('repair_order_id', '=', self.id)],
        }

    def action_view_invoice(self):
        return {
            'name': _('Facture'),
            'view_type': 'form',
            'view_mode': 'kanban,tree,form',
            'res_model': 'account.move',
            'view_id': False,
            'type': 'ir.actions.act_window',
            'domain': [('repair_order_id', '=', self.id)],
        }

    # actions boutons
    def action_view_quotation(self):
        return {
            'name': _('Cotations'),
            'view_type': 'form',
            'view_mode': 'tree,form',
            'res_model': 'sale.order',
            'view_id': False,
            'type': 'ir.actions.act_window',
            'domain': [('repair_order_id', '=', self.id)],
        }

    def action_view_stock_picking(self):
        return {
            'name': _('Transfert'),
            'view_type': 'form',
            'view_mode': 'tree,form',
            'res_model': 'stock.picking',
            'view_id': False,
            'type': 'ir.actions.act_window',
            'domain': [('repair_order_id', '=', self.id)],
        }

    def action_received(self):
        for rec in self:
            if rec.service_mechanical is False and rec.service_bodywork is False and rec.service_painting is False:
                raise ValidationError(
                    _("Veuillez affecter l'ordre de réparation à au moins un atelier avant de réceptionner."))
            if rec.insurance == 'yes':
                if rec.expertise == 'yes' and len(rec.expertise_doc_ids) == 0:
                    rec.state = '2_insurance'
                else:
                    rec.state = '1_received'
                    return {
                        'effect': {
                            'fadeout': 'slow',
                            'message': 'Le véhicule a été réceptionné avec succès',
                            'type': 'rainbow_man',
                        }
                    }
            else:
                rec.state = '1_received'
                return {
                    'effect': {
                        'fadeout': 'slow',
                        'message': 'Le véhicule a été réceptionné avec succès',
                        'type': 'rainbow_man',
                    }
                }

    def action_in_diagnosis(self):
        for rec in self:
            if rec.state == '2_insurance':
                if len(rec.expertise_doc_ids) == 0:
                    raise ValidationError(
                        _("Veuillez ajouter l'expertise"))
                else:
                    client = self.env['res.partner'].sudo().search([('id', '=', rec.client_id.id)])
                    client.write({
                        'phone': rec.client_phone,
                        'mobile': rec.client_mobile,
                        'email': rec.client_email,
                    })
                    rec.is_diagnostic_mechanical_finish = False
                    rec.is_diagnostic_bodywork_finish = False
                    rec.is_diagnostic_painting_finish = False
                    rec.is_diagnostic_finish = False
                    rec.state = '3_in_diagnosis'
            elif not rec.service_mechanical and not rec.service_bodywork and not rec.service_painting:
                raise ValidationError(
                    _("Veuillez affecter l'ordre de réparation à au moins un service !"))
            else:
                client = self.env['res.partner'].sudo().search([('id', '=', rec.client_id.id)])
                client.write({
                    'phone': rec.client_phone,
                    'mobile': rec.client_mobile,
                    'email': rec.client_email,
                })
                rec.state = '3_in_diagnosis'

    def action_cancel(self):
        for rec in self:
            if rec.state == '1_received':
                rec.state = '92_cancel'
            elif rec.state in ['2_insurance', '3_in_diagnosis', '4_waiting_quotation', '5_waiting_customer_validation']:
                if rec.quotation_count == 0:
                    rec.state = '92_cancel'
                else:
                    quotations = self.env['sale.order'].sudo().search([('id', 'in', rec.quotation_ids.ids)])
                    list_quotation = []
                    for quotation in quotations:
                        list_quotation.append('\t- Devis - référence : ' + str(quotation.name))
                    convert_message_to_string = '\n'.join([i for i in list_quotation])
                    return {
                        'type': 'ir.actions.act_window',
                        'view_mode': 'form',
                        'view_type': 'form',
                        'readonly': False,
                        'name': 'Attention',
                        'res_model': 'message.wizard',
                        'target': 'new',
                        'context': {
                            "default_messages": convert_message_to_string
                        }
                    }

    def action_draft(self):
        for rec in self:
            rec.state = '0_draft'

    def action_go_vehicle_delivered(self):
        for rec in self:
            if not rec.output_km_car:
                raise ValidationError(
                    _("Veuillez remplir le champs km sortie avant de livrer le véhicule ! Il se trouve dans l'onglet Véhicule"))
            elif rec.output_km_car < rec.input_km_car:
                raise ValidationError(
                    _("Le kilométrage à la sortie ne peut pas être inférieur au kilométrage à l'entrée du véhicule !"))
            else:
                rec.vehicle_id.odometer = rec.output_km_car
                rec.state = '91_Vehicle_delivered'
                return {
                    'effect': {
                        'fadeout': 'slow',
                        'message': 'Le véhicule a été livré avec succès',
                        'type': 'rainbow_man',
                    }
                }

    def action_finish(self):
        list_workshop = []
        company = self.env.context['allowed_company_ids'][0]
        stock_picking = self.env['stock.picking'].sudo().search([
            ('company_id', '=', company),
            ('picking_type_code', '=', 'internal'),
            ('repair_order_id', '=', self.id),
        ])

        for pick in stock_picking:
            if pick.state == 'done':
                for move_line in pick.move_ids_without_package:
                    list_workshop.append(
                        (0, 0, {'article_id': move_line.product_id.id, 'quantity': move_line.quantity_done}))

        temp_dict = {}
        for item in list_workshop:
            article_id = item[2]['article_id']
            quantity = item[2]['quantity']
            if article_id in temp_dict:
                temp_dict[article_id] += quantity
            else:
                temp_dict[article_id] = quantity

        grouped_list = [(0, 0, {'article_id': k, 'quantity': v}) for k, v in temp_dict.items()]

        for rec in self:
            is_work_mechanical_finish = True
            is_work_bodywork_finish = True
            is_work_painting_finish = True
            for work_mechanical in rec.work_mechanical_ids:
                if work_mechanical.state != '1_finished':
                    is_work_mechanical_finish = False
            for work_bodywork in rec.work_bodywork_ids:
                if work_bodywork.state != '1_finished':
                    is_work_bodywork_finish = False
            for work_painting in rec.work_painting_ids:
                if work_painting.state != '1_finished':
                    is_work_painting_finish = False
            if is_work_mechanical_finish and is_work_bodywork_finish and is_work_painting_finish:
                total_real = 0.0
                for mechanical_line in rec.work_mechanical_ids:
                    if mechanical_line.state == '1_finished':
                        total_real += mechanical_line.time_work
                for bodywork_line in rec.work_bodywork_ids:
                    if bodywork_line.state == '1_finished':
                        total_real += bodywork_line.time_work
                for painting_line in rec.work_painting_ids:
                    if painting_line.state == '1_finished':
                        total_real += painting_line.time_work
                rec.real_total = total_real

                # rec.state = "90_finished"
                return {
                    'type': 'ir.actions.act_window',
                    'view_mode': 'form',
                    'view_type': 'form',
                    'readonly': False,
                    'name': 'Attention',
                    'res_model': 'repair.inventory.wizard',
                    'target': 'new',
                    'context': {
                        'default_repair_inventory_line_wizard_ids': grouped_list,
                    }
                }
            else:
                raise ValidationError(
                    _("Veuillez terminer l'ensemble des travaux de cet ordre de réparation avant de terminer l'ordre "
                      "de réparation"))

    @api.model
    def create(self, vals):
        # génération de numéro de séquence
        if vals['signature_customer']:
            vals['date_signature_customer'] = datetime.now()
        if vals.get('signature_reception'):
            vals['date_signature_recept'] = datetime.now()
        if vals.get('reference', _('Nouveau')) == _('Nouveau'):
            vals['reference'] = self.env['ir.sequence'].sudo().next_by_code('repair.order') or _('Nouveau')
        res = super(RepairOrder, self).create(vals)

        # fix attachment ownership
        for template in res:
            if template.expertise_doc_ids:
                template.expertise_doc_ids.write({'res_model': self._name, 'res_id': template.id})
            if template.repair_order_ids:
                template.repair_order_ids.write({'res_model': self._name, 'res_id': template.id})
            if template.images_car:
                template.images_car.write({'res_model': self._name, 'res_id': template.id})
            if template.technical_file:
                template.technical_file.write({'res_model': self._name, 'res_id': template.id})
            if template.form_report:
                template.form_report.write({'res_model': self._name, 'res_id': template.id})
        return res

    def write(self, vals):
        if vals.get('signature_customer'):
            vals['date_signature_customer'] = datetime.now()
        if vals.get('signature_reception'):
            vals['date_signature_recept'] = datetime.now()

        # permettre à tous les utilisateurs de voir les fichiers chargés
        if vals.get('expertise_doc_ids'):
            for template in self:
                if template.expertise_doc_ids:
                    template.expertise_doc_ids.write({'res_model': self._name, 'res_id': template.id})
        if vals.get('repair_order_ids'):
            for template in self:
                if template.repair_order_ids:
                    template.repair_order_ids.write({'res_model': self._name, 'res_id': template.id})
        if vals.get('images_car'):
            for template in self:
                if template.images_car:
                    template.images_car.write({'res_model': self._name, 'res_id': template.id})
        if vals.get('technical_file'):
            for template in self:
                if template.technical_file:
                    template.technical_file.write({'res_model': self._name, 'res_id': template.id})
        if vals.get('form_report'):
            for template in self:
                if template.form_report:
                    template.form_report.write({'res_model': self._name, 'res_id': template.id})
        res = super(RepairOrder, self).write(vals)
        return res

    def _where_sale(self):
        return """
            r.active IS NOT NULL"""

    @property
    def _table_query(self):
        with_ = ""
        teest = f"""
            {"WITH" + with_ + "(" if with_ else ""}
            SELECT
            MIN(r.id) AS id,
            r.state,
            r.message_main_attachment_id as message_main_attachment_id,
            r.active as active,
            r.client_phone as client_phone,
            r.create_date as create_date,
            r.reference as reference,
            r.vip_customer as vip_customer,
            r.is_client_express as is_client_express,
            r.priority as priority,
            r.receipt_date as receipt_date,
            r.expertise as expertise,
            r.client_mobile as client_mobile,
            r.ratio_hour_repair as ratio_hour_repair,
            r.client_email as client_email,
            r.client_id as client_id,
            r.claim_number as claim_number,
            r.service_mechanical as service_mechanical,
            r.vehicle_id as vehicle_id,
            r.service_painting as service_painting,
            r.chassis_number_car as chassis_number_car,
            r.output_km_car as output_km_car,
            r.fuel_type_car as fuel_type_car,
            r.service_bodywork as service_bodywork,
            r.input_km_car as input_km_car,
            r.cigarette_lighter as cigarette_lighter,
            r.radio as radio,
            r.windshield_wiper as windshield_wiper,
            r.antenna as antenna,
            r.mirror as mirror,
            r.hubcap as hubcap,
            r.cd_or_usb as cd_or_usb,
            r.spare_tire as spare_tire,
            r.jack as jack,
            r.note as note,
            r.carbon_plug as carbon_plug,
            r.toolkit as toolkit,
            r.level_fuel as level_fuel,
            r.intervention as intervention,
            r.is_registration_card as is_registration_card,
            r.is_sticker as is_sticker,
            r.win_hour as win_hour,
            r.end_date_insurance as end_date_insurance,
            r.is_insurance_vehicule_card as is_insurance_vehicule_card,
            r.quotation_count as quotation_count,
            r.is_diagnostic_finish as is_diagnostic_finish,
            r.is_diagnostic_painting_finish as is_diagnostic_painting_finish,
            r.is_diagnostic_bodywork_finish as is_diagnostic_bodywork_finish,
            r.is_diagnostic_mechanical_finish as is_diagnostic_mechanical_finish,
            r.technical_visit_date as technical_visit_date,
            r.purchase_count as purchase_count,
            r.account_count as account_count,
            r.date_signature_recept as date_signature_recept,
            r.date_signature_customer as date_signature_customer,
            r.insurance as insurance,
            r.create_uid as create_uid,
            r.write_uid  as write_uid,
            r.write_date  as write_date,
            r.theorical_total  as theorical_total,
            r.real_total  as real_total,
            r.user_id as user_id,
            r.workshop as workshop,
            r.stock_picking_in_count as stock_picking_in_count,
            r.stock_picking_out_count as stock_picking_out_count,
            r.vehicle as vehicle,
            r.date_of_accident as date_of_accident,
            COUNT(*) as count_repair
            FROM repair_order r
            WHERE {self._where_sale()}
            GROUP BY
            r.state,
            r.theorical_total,
            r.real_total,
            r.ratio_hour_repair,
            r.note,
            r.create_uid,
            r.write_date,
            r.write_uid ,
            r.user_id,
            r.date_signature_recept,
            r.date_signature_customer,
            r.purchase_count,
            r.account_count,
            r.quotation_count,
            r.end_date_insurance,
            r.is_insurance_vehicule_card,
            r.spare_tire,
            r.is_sticker,
            r.is_registration_card,
            r.is_diagnostic_finish,
            r.is_diagnostic_painting_finish,
            r.is_diagnostic_bodywork_finish,
            r.is_diagnostic_mechanical_finish,
            r.level_fuel,
            r.carbon_plug,
            r.jack,
            r.toolkit,
            r.cd_or_usb,
            r.hubcap,
            r.mirror,
            r.win_hour,
            r.windshield_wiper,
            r.radio,
            r.antenna,
            r.cigarette_lighter,
            r.input_km_car,
            r.output_km_car,
            r.fuel_type_car,
            r.chassis_number_car,
            r.service_painting,
            r.message_main_attachment_id,
            r.active,
            r.service_bodywork,
            r.create_date,
            r.receipt_date,
            r.service_mechanical,
            r.technical_visit_date,
            r.priority,
            r.reference,
            r.is_client_express,
            r.vip_customer,
            r.expertise,
            r.claim_number,
            r.client_phone,
            r.client_mobile,
            r.client_id,
            r.vehicle_id,
            r.client_email,
            r.insurance,
            r.intervention,
            r.workshop,
            r.stock_picking_in_count,
            r.stock_picking_out_count,
            r.vehicle,
            r.date_of_accident
            {")" if with_ else ""}
        """
        return teest

