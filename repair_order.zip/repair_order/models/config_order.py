from odoo import api, fields, models


class ConfigOrder(models.Model):
    _name = "config.order"
    _description = "Config Order"

    DEFAULT_TERMS_USE = """# Variables disponibles :
    # - self : objet courant
    # - self.env : Environnement Odoo sur lequel l'action est déclenchée
    # - self.env.user : Renvoie l'utilisateur courant (en tant qu'instance)
    # - self.env.is_system : Retourne si l'utilisateur courant a le groupe 'Settings', ou est en mode super-utilisateur.
    # - self.env.is_admin : Retourne si l'utilisateur courant a le groupe 'Droits d'accès', ou est en mode super-utilisateur.
    # - self.env.is_superuser : Retourne si l'environnement est en mode super-utilisateur.
    # - self.env.company : Renvoie la société actuelle (en tant qu'instance)
    # - self.env.companies : Renvoie un jeu d'enregistrements des sociétés activées par l'utilisateur
    # - self.env.lang : Renvoie le code de la langue courante 
    # - self.env.cr : Curseur
    # - self.env.context : Context
    \n\n\n\n
    """
    terms_use = fields.Text(string="Conditions d'utilisation", default=DEFAULT_TERMS_USE)

    def action_clear(self):
        pass

    def action_execute(self):
        pass
