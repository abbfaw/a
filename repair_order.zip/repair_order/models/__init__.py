# -*- coding: utf-8 -*-

from . import repair_order
from . import diagnostic
from . import repairs
from . import fleet_vehicle
from . import sale_order
from . import product_pricelist
from . import purchase_order
from . import stock_picking
from . import account_move
from . import res_partner
from . import product_template
from . import product_category
from . import account_payment
from . import fact_sheet
from . import config_order
from . import exit_voucher
from . import stock_move
from . import res_users


