# -*- coding: utf-8 -*-

from odoo import models, fields, api, _


class FactSheet(models.Model):
    _name = 'fact.sheet'
    _description = 'Fact Sheet'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string='Nom')
    repair_order_id = fields.Many2one('repair.order', string='Ordre de réparation')

    # Documents véhicule
    key_vehicle_start = fields.Boolean(string="Clé du véhicule", default=False)
    gray_card_start = fields.Boolean(string="Carte grise", default=False)
    assurance_start = fields.Boolean(string="Assurance", default=False)
    supported_start = fields.Boolean(string="Prise en charge", default=False)
    expert_report_start = fields.Boolean(string="Rapport expert", default=False)
    maintenance_log_start = fields.Boolean(string="Carnet entretien", default=False)

    key_vehicle_end = fields.Boolean(default=False)
    gray_card_end = fields.Boolean(default=False)
    assurance_end = fields.Boolean(default=False)
    supported_end = fields.Boolean(default=False)
    expert_report_end = fields.Boolean(default=False)
    maintenance_log_end = fields.Boolean(default=False)

    # Equipements véhicule
    radio_start = fields.Boolean(string="Radio", default=False)
    triangle_start = fields.Boolean(string="Triangle", default=False)
    jack_start = fields.Boolean(string="Crick", default=False)
    crank_start = fields.Boolean(string="Manivelle", default=False)
    extension_jack_start = fields.Boolean(string="Rallonge crick", default=False)
    wheel_wrench_start = fields.Boolean(string="Clé de roue", default=False)
    tool_kit_start = fields.Boolean(string="Trousse à outils", default=False)
    extinguisher_start = fields.Boolean(string="Extincteur", default=False)
    spare_wheel_start = fields.Boolean(string="Roue secours", default=False)

    radio_end = fields.Boolean(default=False)
    triangle_end = fields.Boolean(default=False)
    jack_end = fields.Boolean(default=False)
    crank_end = fields.Boolean(default=False)
    extension_jack_end = fields.Boolean(default=False)
    wheel_wrench_end = fields.Boolean(default=False)
    tool_kit_end = fields.Boolean(default=False)
    extinguisher_end = fields.Boolean(default=False)
    spare_wheel_end = fields.Boolean(default=False)

    # Intérieur
    sum_visor_start = fields.Boolean(string="Pare soleil G/D", default=False)
    inner_rear_mirror_start = fields.Boolean(string="Rétroviseur intérieur", default=False)
    ashtray_start = fields.Boolean(string="Cendrier", default=False)
    ground_sheet_start = fields.Boolean(string="Tapis de sol", default=False)
    inside_lighting_start = fields.Boolean(string="Eclairage intérieur", default=False)
    air_conditioner_start = fields.Boolean(string="Climatisation", default=False)

    sum_visor_end = fields.Boolean(default=False)
    inner_rear_mirror_end = fields.Boolean(default=False)
    ashtray_end = fields.Boolean(default=False)
    ground_sheet_end = fields.Boolean(default=False)
    inside_lighting_end = fields.Boolean(default=False)
    air_conditioner_end = fields.Boolean(default=False)

    # Extérieur
    wheel_studs_start = fields.Boolean(string="Goujons de roue", default=False)
    hubcap_start = fields.Boolean(string="Enjoliveur de roue", default=False)
    side_mirror_start = fields.Boolean(string="Rétroviseur extérieur", default=False)
    repeater_lights_start = fields.Boolean(string="Feux repetiteurs", default=False)
    fuel_door_start = fields.Boolean(string="Trappe à carburant", default=False)
    brushes_start = fields.Boolean(string="Balais AV/AR", default=False)
    radio_antenna_start = fields.Boolean(string="Antenne radio", default=False)

    wheel_studs_end = fields.Boolean(default=False)
    hubcap_end = fields.Boolean(default=False)
    side_mirror_end = fields.Boolean(default=False)
    repeater_lights_end = fields.Boolean(default=False)
    fuel_door_end = fields.Boolean(default=False)
    brushes_end = fields.Boolean(default=False)
    radio_antenna_end = fields.Boolean(default=False)
