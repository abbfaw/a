# -*- coding: utf-8 -*-

from odoo import models, fields, api, _


class StockPickingType(models.Model):
    _inherit = "stock.picking.type"

    workshop_concerned = fields.Selection([
        ('0_mechanical', 'Atelier mécanique'),
        ('1_bodywork', 'Atelier tôlerie'),
        ('2_painting', 'Atelier peinture'),
        ('3_return', 'Retour'),
    ], string="Atelier concerné")

    