# -*- coding: utf-8 -*-

"""
Ce model d'héritage du model account.move est fait pour faire un lien entre l'ordre de réparation et les factures.

"""

from odoo import models


class AccountPayment(models.Model):
    _inherit = "account.payment"

    def action_post(self):
        res = super(AccountPayment, self).action_post()
        for rec in self:
            rec.partner_id.call_invoice()
        return res

    def action_draft(self):
        res = super(AccountPayment, self).action_draft()
        for rec in self:
            rec.partner_id.call_invoice()
        return res
