# -*- coding: utf-8 -*-

from odoo import models, fields, api, _


class ProductPricelist(models.Model):
    _inherit = "product.pricelist"

    is_pricelist_express = fields.Boolean(string="Client express ?", default=False)
