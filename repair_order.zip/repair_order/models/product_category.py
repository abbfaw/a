# -*- coding: utf-8 -*-

from odoo import fields, models, api, _


class ProductCategory(models.Model):
    _inherit = "product.category"

    is_package = fields.Boolean(string="Forfait", default=False)
    is_workforce = fields.Boolean(string="Main d'oeuvre", default=False)
    is_product = fields.Boolean(string="Produit", default=False)
    is_other = fields.Boolean(string="Autre", default=False)

