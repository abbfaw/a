# -*- coding: utf-8 -*-

import time
from odoo import models, fields, api, _


class FleetVehicle(models.Model):
    _inherit = "fleet.vehicle"
    _rec_name = "license_plate"

    client_id = fields.Many2one('res.partner', string='Client')
    client_phone = fields.Char(string='Téléphone', readonly=True)
    client_mobile = fields.Char(string='Mobile', readonly=True)
    client_email = fields.Char(string='Email', readonly=True)

    is_client = fields.Boolean(string="Est un client ?", default=True)
    is_driver = fields.Boolean(string="Est un conducteur ?", default=False)

    repair_order_count = fields.Integer(string="Compte OR véhicule", compute='_compute_repair_order_id', store=True)
    repair_order_ids = fields.One2many('repair.order', 'vehicle_id', string='Ordre de réparation',
                                       copy=False)
    insurance_id = fields.Many2one('res.partner', string='Assurance', tracking=True)
    technical_visit_date = fields.Date(string='Date de visite technique',
                                       tracking=True, required=True, default=time.strftime('%Y-12-31'))
    license_plate = fields.Char(tracking=True, required=True, string='Immatriculation',
                                help='License plate number of the vehicle (i = plate number for a car)')
    vin_sn = fields.Char('Chassis Number', help='Unique number written on the vehicle motor (VIN/SN number)',
                         copy=False, required=True)
    insurance_contract = fields.Many2many(
        'ir.attachment',
        'insurance_contract_doc_rel',
        string="Contrat assurance", help="C'est le contrat de l'assurance"
    )

    @api.depends('repair_order_ids')
    def _compute_repair_order_id(self):
        for rec in self:
            rec.repair_order_count = len(rec.repair_order_ids)

    def action_return_repair_order(self):
        return {
            'name': _('Ordre de réparation'),
            'view_type': 'form',
            'view_mode': 'kanban,tree,form',
            'res_model': 'repair.order',
            'view_id': False,
            'type': 'ir.actions.act_window',
            'domain': [('vehicle_id', '=', self.id)],
        }

    @api.onchange('is_client')
    def onchange_form_client(self):
        for rec in self:
            if rec.is_client:
                rec.is_driver = False
            else:
                rec.is_driver = True

    @api.onchange('is_driver')
    def onchange_form_driver(self):
        for rec in self:
            if rec.is_driver:
                rec.is_client = False
            else:
                rec.is_client = True

    @api.onchange('client_id')
    def onchange_partner_id(self):
        addr = {}
        if self.client_id:
            addr = self.client_id.address_get(['contact'])
            addr['client_phone'] = self.client_id.phone
            addr['client_mobile'] = self.client_id.mobile
            addr['client_email'] = self.client_id.email
        return {'value': addr}
