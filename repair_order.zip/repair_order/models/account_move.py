# -*- coding: utf-8 -*-

"""
Ce model d'héritage du model account.move est fait pour faire un lien entre l'ordre de réparation et les factures.

"""

from odoo import fields, models, api, _


class AccountMove(models.Model):
    _inherit = 'account.move'

    repair_order_id = fields.Many2one(
        'repair.order',
        string='Ordre de réparation',
        domain=[('state', 'not in', ['91_Vehicle_delivered', '92_cancel'])]
    )
    vehicle = fields.Char(string='Véhicule', compute='_compute_car_info', store=True)
    license_plate = fields.Char(string='Immatriculation', compute='_compute_car_info', store=True)
    chassis_vehicle = fields.Char(string='Numéro chassis', compute='_compute_car_info', store=True)

    @api.depends('repair_order_id')
    def _compute_car_info(self):
        for rec in self:
            rec.vehicle = rec.vehicle = rec.repair_order_id.vehicle
            rec.license_plate = rec.repair_order_id.vehicle_id.license_plate
            rec.chassis_vehicle = rec.repair_order_id.chassis_number_car

    def action_return_repair_order(self):
        self.ensure_one()
        return {
            'name': _('Ordre de réparation'),
            'view_type': 'form',
            'view_mode': 'tree,form',
            'res_model': 'repair.order',
            'view_id': False,
            'type': 'ir.actions.act_window',
            'domain': [('id', '=', self.repair_order_id.id)],
        }

    def action_print_invoice(self):
        data = {}
        data.setdefault('id_object', []).append(self.id)
        for order in self.invoice_line_ids:
            if order.product_id.id:
                if order.product_id.categ_id.is_product:
                    taxe_name = ', '.join(map(lambda x: x.name, order.tax_ids))
                    product = {
                        'id': order.product_id.categ_id.id,
                        'name': order.product_id.categ_id.name,
                        'quantity': 1.00,
                        'unite': order.product_uom_id,
                        'price_subtotal': order.price_subtotal,
                        'price_unit': order.price_subtotal,
                        'taxes': taxe_name,
                    }
                    data.setdefault('product', []).append(product)
                elif order.product_id.categ_id.is_workforce:
                    taxe_name = ', '.join(map(lambda x: x.name, order.tax_ids))
                    product = {
                        'id': order.product_id.categ_id.id,
                        'name': order.product_id.categ_id.name,
                        'quantity': order.quantity,
                        'unite': order.product_uom_id,
                        'price_subtotal': order.price_subtotal,
                        'price_unit': order.price_unit,
                        'taxes': taxe_name,
                    }
                    data.setdefault('work_force', []).append(product)
                else:
                    taxe_name = ', '.join(map(lambda x: x.name, order.tax_ids))
                    product = {
                        'id': order.product_id.categ_id.id,
                        'name': order.product_id.categ_id.name,
                        'quantity': order.quantity,
                        'unite': order.product_uom_id,
                        'price_subtotal': order.price_subtotal,
                        'price_unit': order.price_unit,
                        'taxes': taxe_name,
                    }
                    data.setdefault('other', []).append(product)

        list_product = {}
        final_product = []
        list_work = {}
        final_work = []

        if 'product' not in data:
            data['product'] = []
        else:
            for product in data['product']:
                name_product = product['name']
                if name_product in list_product:
                    list_product[name_product]['price_subtotal'] += product['price_subtotal']
                    list_product[name_product]['price_unit'] += product['price_unit']
                else:
                    list_product[name_product] = product

            for list_product_lines in list_product.items():
                final_product.append(list_product_lines[1])

            data['product'] = final_product

        if 'work_force' not in data:
            data['work_force'] = []
        else:
            for work in data['work_force']:
                name_product = work['name']
                if name_product in list_work:
                    list_work[name_product]['quantity'] += work['quantity']
                    list_work[name_product]['price_subtotal'] += work['price_subtotal']
                else:
                    list_work[name_product] = work

            for list_work_lines in list_work.items():
                final_work.append(list_work_lines[1])

            data['work_force'] = final_work

        if 'other' not in data:
            data['other'] = []
        return self.env.ref('repair_order.action_report_customer_invoice').report_action([], data=data)


class AccountMoveReportData(models.AbstractModel):
    _name = 'report.repair_order.report_customer_invoice'

    @api.model
    def _get_report_values(self, docids, data=None):
        docs = self.env['account.move'].browse(data['id_object'][0])
        print("docso.repair_order_id.vehicle_id =", docs.repair_order_id.vehicle_id)
        print("docso =", docs)
        print("docso.name =", docs.name)
        print("docso.name =", docs.partner_id.name)
        print("data =", data)
        return {
            'doc_ids': docids,
            'doc_model': 'account.move',
            'docs': docs,
            'data': data
        }