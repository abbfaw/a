# -*- coding: utf-8 -*-

"""
Ce model d'héritage du model sale.order est fait pour faire un lien entre l'ordre de réparation et le devis

"""

from odoo import fields, models, api, _
from odoo.exceptions import ValidationError
from datetime import datetime
from odoo.tools.misc import formatLang
from collections import defaultdict
from pprint import pprint

CONDITION = """
NB : Acompte 50% avant tous travaux. Remise non valable pour dossier "prise en charge assurance". Compte tenu de la situation de la COVID 19, les prix des pièces peuvent changer au-delà d'une semaine des réceptions du devis.
"""


class SaleOrder(models.Model):
    _inherit = 'sale.order'

    repair_order_id = fields.Many2one(
        'repair.order',
        string='Ordre de réparation',
        domain=[('state', 'not in', ['90_finished', '91_Vehicle_delivered', '92_cancel'])]
    )
    is_client_express = fields.Boolean(default=False, string="Client express")
    vehicle = fields.Char(string='Véhicule', compute='_compute_car_info', store=True)
    license_plate = fields.Char(string='Immatriculation', compute='_compute_car_info', store=True)
    chassis_vehicle = fields.Char(string='Numéro chassis', compute='_compute_car_info', store=True)
    year_car = fields.Char(string='Année', compute='_compute_car_info', store=True)
    state = fields.Selection(
        selection=[
            ('draft', "Devis"),
            ('progress', "Validé service achat"),
            ('validate', "Validé par supérieur"),
            ('sent', "Devis Envoyé"),
            ('sale', "Bon de commande"),
            ('done', "Bloqué"),
            ('cancel', "Annulé"),
        ],
        string="Status",
        readonly=True, copy=False, index=True,
        tracking=3,
        default='draft')
    note = fields.Html(
        string="Terms and conditions",
        compute='_compute_note',
        store=True, readonly=False, precompute=True, default=CONDITION)

    @api.depends('repair_order_id')
    def _compute_car_info(self):
        for rec in self:
            rec.vehicle = rec.vehicle = rec.repair_order_id.vehicle
            rec.license_plate = rec.repair_order_id.vehicle_id.license_plate
            rec.chassis_vehicle = rec.repair_order_id.chassis_number_car
            rec.year_car = rec.repair_order_id.vehicle_id.model_year

    def action_confirm_sale(self):
        for rec in self:
            rec.state = 'progress'
            if rec.repair_order_id and rec.repair_order_id.state in ['2_insurance', '3_in_diagnosis',
                                                                     '4_waiting_quotation']:
                rec.repair_order_id.state = '5_waiting_customer_validation'

    def action_confirm_sale_sup(self):
        for rec in self:
            rec.signed_by = self.env.user.name
            rec.signed_on = datetime.now()
            rec.signature = self.env.user.signature_sale if self.env.user.signature_sale else False
            rec.state = 'validate'

    def action_preview_quotation(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_url',
            'target': 'self',
            'url': "/repair_order/preview/quotation/" + str(self.id),
        }

    def action_print_quotation(self):
        data = {}
        data.setdefault('id_object', []).append(self.id)
        for order in self.order_line:
            if order.product_id.id:
                if order.product_id.categ_id.is_product:
                    taxe_name = ', '.join(map(lambda x: x.name, order.tax_id))
                    product = {
                        'id': order.product_id.categ_id.id,
                        'name': order.product_id.categ_id.name.capitalize(),
                        'quantity': 1.00,
                        'unite': 'Unités',
                        'price_subtotal': order.price_subtotal,
                        'price_unit': order.price_subtotal,
                        'taxes': taxe_name,
                    }
                    data.setdefault('product', []).append(product)
                elif order.product_id.categ_id.is_workforce:
                    taxe_name = ', '.join(map(lambda x: x.name, order.tax_id))
                    product = {
                        'id': order.product_id.categ_id.id,
                        'name': order.product_id.categ_id.name.capitalize(),
                        'quantity': order.product_uom_qty,
                        'unite': 'Heures',
                        'price_subtotal': order.price_subtotal,
                        'price_unit': order.price_unit,
                        'taxes': taxe_name,
                    }
                    data.setdefault('work_force', []).append(product)
                elif order.product_id.categ_id.is_package:
                    taxe_name = ', '.join(map(lambda x: x.name, order.tax_id))
                    product = {
                        'id': order.product_id.categ_id.id,
                        'name': order.product_id.name.capitalize(),
                        'quantity': order.product_uom_qty,
                        'unite': 'Unités',
                        'price_subtotal': order.price_subtotal,
                        'price_unit': order.price_unit,
                        'taxes': taxe_name,
                    }
                    data.setdefault('package', []).append(product)
                elif order.product_id.categ_id.is_other:
                    taxe_name = ', '.join(map(lambda x: x.name, order.tax_id))
                    product = {
                        'id': order.product_id.categ_id.id,
                        'name': order.product_id.name.capitalize(),
                        'quantity': order.product_uom_qty,
                        'unite': 'Unités',
                        'price_subtotal': order.price_subtotal,
                        'price_unit': order.price_unit,
                        'taxes': taxe_name,
                    }
                    data.setdefault('other', []).append(product)
                else:
                    taxe_name = ', '.join(map(lambda x: x.name, order.tax_id))
                    product = {
                        'id': order.product_id.categ_id.id,
                        'name': order.product_id.categ_id.name.capitalize(),
                        'quantity': order.product_uom_qty,
                        'unite': order.product_uom.name,
                        'price_subtotal': order.price_subtotal,
                        'price_unit': order.price_unit,
                        'taxes': taxe_name,
                    }
                    data.setdefault('part', []).append(product)

        list_product = {}
        final_product = []
        list_work = {}
        final_work = []

        if 'product' not in data:
            data['product'] = []
        else:
            for product in data['product']:
                name_product = product['name']
                if name_product in list_product:
                    list_product[name_product]['price_subtotal'] += product['price_subtotal']
                    list_product[name_product]['price_unit'] += product['price_unit']
                else:
                    list_product[name_product] = product

            for list_product_lines in list_product.items():
                final_product.append(list_product_lines[1])

            data['product'] = final_product

        if 'work_force' not in data:
            data['work_force'] = []
        else:
            for work in data['work_force']:
                name_product = work['name']
                if name_product in list_work:
                    list_work[name_product]['quantity'] += work['quantity']
                    list_work[name_product]['price_subtotal'] += work['price_subtotal']
                else:
                    list_work[name_product] = work

            for list_work_lines in list_work.items():
                final_work.append(list_work_lines[1])

            data['work_force'] = final_work

        if 'other' not in data:
            data['other'] = []
        if 'package' not in data:
            data['package'] = []
        if 'part' not in data:
            data['part'] = []
        print('data =', data)
        print('self.env.context =', self.env.context.get('out_car'))
        if self.env.context.get('out_car'):
            return self.env.ref('repair_order.action_report_out_vehicle').report_action([], data=data)
        else:
            return self.env.ref('repair_order.action_report_customer_quotation').report_action([], data=data)

    def action_confirm(self):
        is_waiting_part = False
        for rec in self:
            if rec.repair_order_id:
                for order in rec.order_line:
                    """Nous vérifions s'il y a une pièce qui est rupture de stock, cela nous permettra
                    de faire passer le statut de l'ordre de réparation à en attente de pièce"""
                    qty_necessary = order.product_id.qty_available - order.product_uom_qty
                    is_waiting_part = False if qty_necessary >= 0 else True
                    print('qty_necessary =', qty_necessary)
                # rec.action_transfer_request()
                print('is_waiting_part =', is_waiting_part)
                if rec.repair_order_id.state not in ['0_draft', '1_received', '3_in_diagnosis', '2_insurance',
                                                     '8_in_progress', '90_finished', '92_cancel',
                                                     '91_Vehicle_delivered']:
                    rec.repair_order_id.state = '6_waiting_parts' if is_waiting_part else '7_ready'
                rec.state = 'sale'
                """Lorsque le devis en cours passent en bon de commande, nous allons annuler les autres devis en cours
                de cet ordre de réparation"""
                for quotation in rec.repair_order_id.quotation_ids:
                    if quotation.id != self.id:
                        quotation.state = "cancel"
            else:
                super(SaleOrder, self).action_confirm()

    def action_cancel(self):
        for rec in self:
            if rec.repair_order_id:
                """Si le devis est au statut bon de commande on ne permet plus qu'il soit annuler"""
                if rec.state == "sale":
                    raise ValidationError(
                        _("Vous ne pouvez pas annuler un devis qui a déjà été validé par le client. Vous pouvez "
                          "l'archiver"))
                """Nous vérifions si le devis est le seul dans l'OR"""
                if len(rec.repair_order_id.quotation_ids) == 1:
                    """Dans ce cas, nous mettons l'OR au statut attente cotation"""
                    if rec.repair_order_id.state != '2_insurance':
                        rec.repair_order_id.state = '4_waiting_quotation'
                    return super(SaleOrder, self).action_cancel()
                else:
                    """Nous vérifions dans le cas où il y a d'autres devis dans l'OR
                                    Si ces devis sont tous au statut annuler
                                    si au moins un des autres frères est au statut devis 
                                    Pour pouvoir faire passer l'OR au statut attente quotation, dans les autres cela n'est pas nécessaire 
                                    car l'OR restera à son même statut"""
                    is_quotation_cancel = True
                    is_quotation_draft = False
                    for quotation in rec.repair_order_id.quotation_ids:
                        if quotation.state != "cancel" and quotation.id != rec.id:
                            is_quotation_cancel = False
                        if quotation.state == "draft" and quotation.id != rec.id:
                            is_quotation_draft = True
                    if is_quotation_cancel or is_quotation_draft:
                        if rec.repair_order_id.state != '2_insurance':
                            rec.repair_order_id.state = '4_waiting_quotation'
                    return super(SaleOrder, self).action_cancel()
            else:
                return super(SaleOrder, self).action_cancel()

    def action_draft(self):
        for rec in self:
            if rec.repair_order_id:
                is_quotation_sale = False
                for quotation in rec.repair_order_id.quotation_ids:
                    if quotation.state == "sale":
                        is_quotation_sale = True
                if is_quotation_sale:
                    raise ValidationError(_("Vous ne pouvez pas remettre en devis ce devis car un autre devis de "
                                            "l'ordre de réparation a déjà été validé par le client"))
                else:
                    if rec.repair_order_id.state != '2_insurance':
                        rec.repair_order_id.state = "4_waiting_quotation"
                    return super(SaleOrder, self).action_draft()
            else:
                return super(SaleOrder, self).action_draft()

    # action buttons
    def action_return_repair_order(self):
        return {
            'name': _('Ordre de réparation'),
            'view_type': 'form',
            'view_mode': 'kanban,tree,form',
            'res_model': 'repair.order',
            'view_id': False,
            'type': 'ir.actions.act_window',
            'domain': [('id', '=', self.repair_order_id.id)],
        }

    def action_purchase_order(self):
        purchase_group_by_vendor = {}
        # is_state_waiting_part = False
        for rec in self:
            for order in rec.order_line:
                # """Nous vérifions s'il y a une pièce qui est rupture de stock, cela nous permettra
                # de faire passer le statut de l'ordre de réparation à en attente de pièce"""
                # qty_necessary = order.product_id.qty_available - order.product_uom_qty
                # is_state_waiting_part = False if qty_necessary >= 0 else True
                if order.product_id.detailed_type == 'product':
                    """ nous récupérons l'Id du fournisseur, s'il y en a plusieurs on prend 1er et s'il n y a pas
                    de fournisseur on prend l'id 1 """
                    vendor = order.product_id.seller_ids[0].partner_id.id if len(order.product_id.seller_ids) > 0 else 1
                    product_to_purchase = {
                        'product_id': order.product_id.id,
                        'name': order.product_id.name,
                        'product_qty': order.product_uom_qty,
                        'price_unit': order.product_id.standard_price,
                        # 'taxes_id': order.tax_id,
                    }
                    """Nous avons créer un dictionnaire pour regrouper les fournisseur par produit et
                    c'est comme cela que nous allons créer les commandes d'achat"""
                    purchase_group_by_vendor.setdefault(vendor, []).append(product_to_purchase)
        for purchase_lines in purchase_group_by_vendor.items():
            vendor_id = purchase_lines[0]
            list_product_in_purchase_lines = purchase_lines[1]
            purchase_vals = {
                'partner_id': vendor_id,
                'state': 'draft',
                'repair_order_id': self.repair_order_id.id,
            }
            order_purchase_id = self.env['purchase.order'].sudo().create(purchase_vals)
            for product_line in list_product_in_purchase_lines:
                product_line['order_id'] = order_purchase_id.id
                self.env['purchase.order.line'].sudo().create(product_line)
        # return is_state_waiting_part

    @api.model
    def create(self, vals):
        if 'company_id' in vals:
            self = self.with_company(vals['company_id'])
        if vals.get('name', _('New')) == _('New'):
            seq_date = None
            if 'date_order' in vals:
                seq_date = fields.Datetime.context_timestamp(self, fields.Datetime.to_datetime(vals['date_order']))
            vals['name'] = self.env['ir.sequence'].next_by_code('repairs.sale', sequence_date=seq_date) or _('New')

        # Makes sure partner_invoice_id', 'partner_shipping_id' and 'pricelist_id' are defined
        if any(f not in vals for f in ['partner_invoice_id', 'partner_shipping_id', 'pricelist_id']):
            partner = self.env['res.partner'].browse(vals.get('partner_id'))
            addr = partner.address_get(['delivery', 'invoice'])
            vals['partner_invoice_id'] = vals.setdefault('partner_invoice_id', addr['invoice'])
            vals['partner_shipping_id'] = vals.setdefault('partner_shipping_id', addr['delivery'])
            vals['pricelist_id'] = vals.setdefault('pricelist_id', partner.property_product_pricelist.id)
        result = super(SaleOrder, self).create(vals)
        return result


class SaleAdvancePaymentInv(models.TransientModel):
    """
    Classe permettant de créer des factures depuis le bon de commande.
    """
    _inherit = "sale.advance.payment.inv"

    def create_invoices(self):
        search_sale_orders = self.env['sale.order'].browse(self._context.get('active_ids', []))
        super(SaleAdvancePaymentInv, self).create_invoices()
        for invoice in search_sale_orders.invoice_ids:
            invoice.write({'repair_order_id': search_sale_orders.repair_order_id})


class SaleOrderReportData(models.AbstractModel):
    _name = 'report.repair_order.report_customer_quotation'

    @api.model
    def _get_report_values(self, docids, data=None):
        docs = self.env['sale.order'].browse(data['id_object'][0])
        return {
            'doc_ids': docids,
            'doc_model': 'sale.order',
            'docs': docs,
            'data': data
        }


class SaleOrderReportDataOutCar(models.AbstractModel):
    _name = 'report.repair_order.report_out_car'

    @api.model
    def _get_report_values(self, docids, data=None):
        docs = self.env['sale.order'].browse(data['id_object'][0])
        return {
            'doc_ids': docids,
            'doc_model': 'sale.order',
            'docs': docs,
            'data': data
        }
