# -*- coding: utf-8 -*-

from odoo import models, fields, api, _


class Repairs(models.Model):
    _inherit = 'repair.order'

    work_mechanical_ids = fields.One2many('repairs.line', 'mechanical_id', string='Atelier Mécanique')
    work_bodywork_ids = fields.One2many('repairs.line', 'bodywork_id', string='Atelier Tôlerie')
    work_painting_ids = fields.One2many('repairs.line', 'painting_id', string='Atelier Peinture')
    real_total = fields.Float(string='Total réel', default=0.0)

    def action_workorder(self):
        for rec in self:
            if rec.mechanical_workshop_ids:
                for mechanical_workshop_line in rec.mechanical_workshop_ids:
                    if mechanical_workshop_line.article_id.detailed_type == 'service':
                        service_line_vals = {
                            'state': '0_draft',
                            'mechanical_id': mechanical_workshop_line.mechanical_id.id,
                            'service_id': mechanical_workshop_line.article_id.id,
                            'quantity': mechanical_workshop_line.quantity,
                            'is_mechanical': True
                        }
                        self.env['repairs.line'].sudo().create(service_line_vals)
            if rec.sheet_metal_workshop_ids:
                for sheet_metal_workshop_line in rec.sheet_metal_workshop_ids:
                    if sheet_metal_workshop_line.article_id.detailed_type == 'service':
                        service_line_vals = {
                            'state': '0_draft',
                            'bodywork_id': sheet_metal_workshop_line.sheet_metal_id.id,
                            'service_id': sheet_metal_workshop_line.article_id.id,
                            'quantity': sheet_metal_workshop_line.quantity,
                            'is_bodywork': True,
                        }
                        self.env['repairs.line'].sudo().create(service_line_vals)
            if rec.paint_workshop_ids:
                for paint_workshop_line in rec.paint_workshop_ids:
                    if paint_workshop_line.article_id.detailed_type == 'service':
                        service_line_vals = {
                            'state': '0_draft',
                            'painting_id': paint_workshop_line.paint_workshop_id.id,
                            'service_id': paint_workshop_line.article_id.id,
                            'quantity': paint_workshop_line.quantity,
                            'is_painting': True,
                        }
                        self.env['repairs.line'].sudo().create(service_line_vals)
            rec.state = '8_in_progress'


class WorkReparationLine(models.Model):
    _name = 'repairs.line'
    _description = 'repairs.line'
    _order = "state desc"
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string='Référence', copy=False, readonly=True, index=True,
                       default=lambda self: _('Nouveau'))
    is_mechanical = fields.Boolean(default=False, string='Service mécanique')
    is_bodywork = fields.Boolean(default=False, string='Service tôlerie')
    is_painting = fields.Boolean(default=False, string='Service peinture')

    mechanical_id = fields.Many2one("repair.order", string="Ordre mécanique",
                                    domain=[('state', '=', '8_in_progress'), ('service_mechanical', '=', True)],
                                    ondelete='cascade')
    bodywork_id = fields.Many2one("repair.order", string="Ordre tôlerie",
                                  domain=[('state', '=', '8_in_progress'), ('service_bodywork', '=', True)],
                                  ondelete='cascade')
    painting_id = fields.Many2one("repair.order", string="Ordre peinture",
                                  domain=[('state', '=', '8_in_progress'), ('service_painting', '=', True)],
                                  ondelete='cascade')
    service_id = fields.Many2one('product.product', string='Service', ondelete='cascade',
                                 domain="[('detailed_type', '=', 'service')]")
    speaker_ids = fields.Many2many(comodel_name='hr.employee', string='Intervenant', ondelete='cascade', tracking=True)
    date_begin = fields.Date(string="Date début", default=fields.Datetime.now, tracking=True)
    date_end = fields.Date(string="Date fin", tracking=True)
    time_work = fields.Float(string='Durée réelle', default=0.0)
    quantity = fields.Float(string='Durée théorique', default=0.0)
    unity_measure = fields.Many2one('uom.uom', "Unité de mesure", related='service_id.uom_po_id', readonly=True)
    state = fields.Selection(selection=[
        ('0_draft', 'A faire'),
        ('1_finished', 'Terminé'),
        ('2_cancel', 'Annulé'),
    ], string='Status', required=True, readonly=True,
        default='0_draft', tracking=True)
    active = fields.Boolean(string="Active", default=True, tracking=True)

    # action button
    def action_finished(self):
        for rec in self:
            rec.state = '1_finished'
            rec.mechanical_id.state = "8_in_progress"

    def action_cancel(self):
        for rec in self:
            rec.state = '2_cancel'

    def action_draft(self):
        for rec in self:
            rec.state = '0_draft'

    @api.model
    def create(self, vals):
        # génération de numéro de séquence
        if vals.get('name', _('Nouveau')) == _('Nouveau'):
            vals['name'] = self.env['ir.sequence'].next_by_code('repairs.line') or _('Nouveau')
        res = super(WorkReparationLine, self).create(vals)
        return res
