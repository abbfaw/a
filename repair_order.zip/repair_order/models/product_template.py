# -*- coding: utf-8 -*-

from odoo import models, fields, api, _


class ProductPricelist(models.Model):
    _inherit = "product.template"

    # is_forfait_product = fields.Boolean(string="Est un forfait", default=False)
    categ_id = fields.Many2one(
        'product.category', 'Product Category re',
        change_default=True, default=None, group_expand='_read_group_categ_id',
        required=True)
    categ_name = fields.Char(related='categ_id.name', readonly=True)

    # @api.onchange('is_forfait_product')
    # def _onchange_is_forfait(self):
    #     for rec in self:
    #         if rec.is_forfait_product:
    #             rec.detailed_type = 'consu'
