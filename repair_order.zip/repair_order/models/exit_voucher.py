# -*- coding: utf-8 -*-

from odoo import models, fields, api, _


class ExitVoucher(models.Model):
    _name = 'exit.voucher'
    _description = 'Exit Voucher'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string='Référence', copy=False, readonly=True, index=True,
                       default=lambda self: _('Nouveau'))
    repair_order_id = fields.Many2one('repair.order', string='Ordre de réparation')
    applicant_ids = fields.Many2many(comodel_name='hr.employee', string='Demandeur', ondelete='cascade', tracking=True)
    client_id = fields.Many2one('res.partner', string='Client', tracking=True, readonly=True)
    vehicle_id = fields.Many2one('fleet.vehicle', string='Immatriculation', readonly=True, tracking=True)
    vehicle = fields.Char(string='Véhicule', compute='_compute_car_info', store=True)
    date = fields.Datetime(string='Date', default=fields.Datetime.now, tracking=True)
    line_ids = fields.One2many(
        comodel_name="exit.voucher.line", inverse_name="voucher_id", string="Line", tracking=True)
    service_mechanical = fields.Boolean(string="Mécanique", default=False, tracking=True)
    service_bodywork = fields.Boolean(string="Tôlerie", default=False, tracking=True)
    service_painting = fields.Boolean(string="Peinture", default=False, tracking=True)
    signature_applicant = fields.Binary(string="Signature demandeur", tracking=True)
    signature_storekeeper = fields.Binary(string="Signature magasinier", tracking=True)
    signature_director = fields.Binary(string="Signature directeur", tracking=True)
    state = fields.Selection(selection=[
        ('0_draft', 'Brouillon'),
        ('1_done', 'Livré'),
        ('3_cancel', 'Annulé'),
    ], string='Status', readonly=True, copy=False, tracking=True, default='0_draft')
    active = fields.Boolean(string="Active", default=True, tracking=True)

    def confirm_signature(self):
        active_id = self._context.get('active_id')
        upd_var = self.env['exit.voucher']
        vals = {
            'signature_applicant': self.signature_applicant,
            'signature_director': self.signature_director,
            'signature_storekeeper': self.signature_storekeeper}
        upd_var.write(vals)
        return {'type': 'ir.actions.client', 'tag': 'reload'}

    def action_done(self):
        for rec in self:
            rec.state = '1_done'

    def action_draft(self):
        for rec in self:
            rec.state = '0_draft'

    def action_cancel(self):
        for rec in self:
            rec.state = '3_cancel'

    @api.depends('repair_order_id')
    def _compute_car_info(self):
        for rec in self:
            rec.vehicle = f"{rec.repair_order_id.mark_car} {rec.repair_order_id.model_car}".upper() if rec.repair_order_id else ""
            rec.vehicle_id = rec.repair_order_id.vehicle_id.id
            rec.client_id = rec.repair_order_id.client_id.id

    @api.model
    def create(self, vals):
        if vals.get('name', _('Nouveau')) == _('Nouveau'):
            vals['name'] = self.env['ir.sequence'].sudo().next_by_code('exit.voucher') or _('Nouveau')
        res = super(ExitVoucher, self).create(vals)
        return res


class ExitVoucherLine(models.Model):
    _name = 'exit.voucher.line'
    _description = 'Exit Voucher Line'

    voucher_id = fields.Many2one(
        "exit.voucher", string="Bon de sortie", ondelete='cascade')
    voucher_wizard_id = fields.Many2one(
        "exit.voucher", string="Bon de sortie wizard", ondelete='cascade')
    product_id = fields.Many2one("product.product",
                                 string="Articles", ondelete='cascade',
                                 domain="[('detailed_type', '=', 'product')]", required=True)
    unity_measure = fields.Many2one('uom.uom', "UdM", related='product_id.uom_po_id', readonly=True)
    description = fields.Char(string="description")
    # number_order = fields.Many2one('stock.picking', string='Numéro BL')
    number_purchase = fields.Char(string='Numéro BL')
    quantity = fields.Float(string='Qté', default=0.0)
