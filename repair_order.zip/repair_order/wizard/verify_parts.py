from odoo import api, fields, models, _
from odoo.exceptions import ValidationError
from odoo.http import request


class VerifyParts(models.TransientModel):
    _name = "verify.parts.wizard"
    _description = "Verifier disponibilité des pièces"

    messages = fields.Text(string="Messages", readonly=True)

    def action_force_or(self):
        request.env['repair.order'].sudo().browse(self._context.get("active_ids")).update({'state': '7_ready'})
        return True
