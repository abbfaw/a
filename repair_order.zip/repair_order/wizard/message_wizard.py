from odoo import api, fields, models, _
from odoo.exceptions import ValidationError
from odoo.http import request


class MessageWizard(models.TransientModel):
    _name = "message.wizard"
    _description = "Afficher un message informatif aux utilisateur"

    messages = fields.Text(string="Messages", readonly=True)

    def action_cancel_or(self):
        repair_order = request.env['repair.order'].sudo().browse(self._context.get("active_ids"))
        quotations = request.env['sale.order'].sudo().search([('id', 'in', repair_order.quotation_ids.ids)])
        for quotation in quotations:
            quotation.state = 'cancel'
        request.env['repair.order'].sudo().browse(self._context.get("active_ids")).update({'state': '92_cancel'})
        return True
