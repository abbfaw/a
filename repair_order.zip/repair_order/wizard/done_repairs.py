import datetime
from odoo import api, fields, models, _
from odoo.exceptions import ValidationError
from odoo.http import request


class DoneRepairsWizard(models.TransientModel):
    _name = "done.repairs.wizard"
    _description = "Done repairs"

    name = fields.Char(string='Référence', copy=False, readonly=True, index=True)
    service_id = fields.Many2one('product.product', string='Service', ondelete='cascade', readonly=True,
                                 domain="[('detailed_type', '=', 'service')]")
    is_mechanical = fields.Boolean(default=False, string='Service mécanique')
    is_bodywork = fields.Boolean(default=False, string='Service tôlerie')
    is_painting = fields.Boolean(default=False, string='Service peinture')
    speaker_ids = fields.Many2many('hr.employee', string='Intervenant', ondelete='cascade', required=True)
    date_begin = fields.Date(string="Date et heure debut", required=True, default=fields.Datetime.now)
    date_end = fields.Date(string="Date et heure fin", required=True, default=fields.Datetime.now)
    time_work = fields.Float(string='Durée travaux', default=0, required=True)

    def action_done(self):
        for rec in self:
            search_repairs = request.env['repairs.line'].sudo().search([
                ('id', '=', self.env.context.get('active_id')),
                ('is_mechanical', '=', rec.is_mechanical),
                ('is_bodywork', '=', rec.is_bodywork),
                ('is_painting', '=', rec.is_painting),
                ('name', '=', rec.name),
            ])
            search_repairs.write({'state': '1_finished', 'speaker_ids': rec.speaker_ids, 'time_work': rec.time_work, 'date_begin': rec.date_begin, 'date_end': rec.date_end})

