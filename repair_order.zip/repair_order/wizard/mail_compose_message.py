# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import models
from odoo.http import request


class MailComposeMessage(models.TransientModel):
    _inherit = 'mail.compose.message'

    def _action_send_mail(self, auto_commit=False):
        """
            Fonction permettant d'écouter l'envoie du devis par mail
        """
        if self.model == 'sale.order':
            self = self.with_context(mailing_document_based=True)
            if self.env.context.get('mark_so_as_sent'):
                self = self.with_context(mail_notify_author=self.env.user.partner_id in self.partner_ids)
                sale = request.env['sale.order'].sudo().search([('id', '=', self.env.context.get('active_id'))])
                if sale.repair_order_id:
                    passage_or_waiting_customer = ['sent', 'cancel']
                    for rec in sale:
                        """Passage du statut devis au statut devis envoyé client"""
                        rec.state = "sent"
                        """Nous vérifions si le devis est le seul dans l'OR"""
                        if len(rec.repair_order_id.quotation_ids) == 1:
                            """Dans ce cas, nous mettons l'OR au statut devis envoyé au client"""
                            if rec.repair_order_id.state != '2_insurance' and rec.repair_order_id.state in ['3_in_diagnosis', '4_waiting_quotation']:
                                rec.repair_order_id.state = '5_waiting_customer_validation'
                        else:
                            """Sinon, nous allons chercher à savoir si tous les autres devis sont au statut envoyé client ou annulé
                            Dans ce cas, nous allons mettre is_quotation_valid à true"""
                            is_quotation_valid = True
                            for quotation in rec.repair_order_id.quotation_ids:
                                if not (quotation.state in passage_or_waiting_customer):
                                    is_quotation_valid = False
                            if is_quotation_valid:
                                if rec.repair_order_id.state != '2_insurance' and rec.repair_order_id.state in ['3_in_diagnosis', '4_waiting_quotation']:
                                    rec.repair_order_id.state = '5_waiting_customer_validation'
        return super(MailComposeMessage, self)._action_send_mail(auto_commit=auto_commit)
