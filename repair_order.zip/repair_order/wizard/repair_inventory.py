from odoo import fields, models, api
from odoo.http import request


class RepairInventoryLineWizard(models.TransientModel):
    _name = "repair.inventory.line.wizard"
    _description = "Lingne d'inventaire de réparation"

    article_id = fields.Many2one("product.product",
                                 string="Articles/Services")
    quantity = fields.Float(string='Qté/Durée', default=0.0, required=True, digits="Product Unit Of Measure",
                            help="La quantité de produit nécessaire.", tracking=True)
    quantity_util = fields.Float(string='Qté utilisée/Durée', default=0.0, tracking=True)
    repair_inventory_wizard_id = fields.Many2one('repair.inventory.wizard')


class RepairInventoryWizard(models.TransientModel):
    _name = "repair.inventory.wizard"
    _description = "Inventaire de réparation"

    repair_inventory_line_wizard_ids = fields.One2many("repair.inventory.line.wizard", string="", inverse_name='repair_inventory_wizard_id')

    def action_done(self):
        for rec in self:
            company = self.env.context['allowed_company_ids'][0]
            active_id = self._context.get('active_id')

            get_picking_type_out = self.env['stock.picking.type'].sudo().search([
                ('company_id', '=', company),
                ('code', '=', 'outgoing')
            ])

            get_picking_type_int = self.env['stock.picking.type'].sudo().search([
                ('company_id', '=', company),
                ('code', '=', 'internal')
            ])

            customers_location = self.env['stock.location'].sudo().search([('name', '=', 'Customers')])
            stock_pick_move = self.env['stock.picking']
            repair_order = self.env['repair.order'].search([('id', '=', active_id)])

            pick_move = {
                "picking_type_id": get_picking_type_out[0].id,
                "repair_order_id": repair_order.id,
                "location_id": get_picking_type_int[0].default_location_dest_id.id,
                "location_dest_id": customers_location.id,
                "immediate_transfer": True,
                "partner_id": repair_order.client_id.id,
                "origin": repair_order.reference,
                "state": "done",
                "move_ids_without_package": [
                    {
                        "name": "SORTIE",
                        "location_id": get_picking_type_int[0].default_location_dest_id.id,
                        "location_dest_id": customers_location.id,
                        "partner_id": repair_order.client_id.id,
                        'product_id': prod.article_id.id,
                        'product_uom_qty': prod.quantity,
                        'quantity_done': prod.quantity_util,
                    } for prod in rec.repair_inventory_line_wizard_ids if prod.quantity_util > 0
                ],
            }

            transfert_obj = stock_pick_move.sudo().create(pick_move)

            # Valider le partner
            transfert_obj.sudo().onchange_partner_id()
            transfert_obj.sudo()._onchange_picking_type()

            recherche_repair = self.env['repair.order'].sudo().search([('id', '=', self.env.context.get('active_id'))])
            recherche_repair.write({'state': '90_finished'})

            # Valider le type d'opération
            return transfert_obj.sudo().button_validate()

