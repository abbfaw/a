# coding: utf-8
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import pos_config
from . import pos_payment_method
from . import pos_session
from . import res_config_settings
