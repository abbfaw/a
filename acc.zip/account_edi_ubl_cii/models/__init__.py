# -*- coding: utf-8 -*-

from . import account_edi_common
from . import account_edi_format
from . import account_edi_xml_cii_facturx
from . import account_edi_xml_ubl_20
from . import account_edi_xml_ubl_21
from . import account_edi_xml_ubl_bis3
from . import account_edi_xml_ubl_xrechnung
from . import account_edi_xml_ubl_nlcius
from . import account_edi_xml_ubl_efff
from . import ir_actions_report
from . import mail_template
