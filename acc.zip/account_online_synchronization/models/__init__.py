# -*- coding: utf-8 -*-

from . import account_bank_statement
from . import account_journal
from . import account_online
from . import company
from . import partner
from . import bank_rec_widget
