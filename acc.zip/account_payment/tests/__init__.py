# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import test_account_payment
from . import test_payment_flows
