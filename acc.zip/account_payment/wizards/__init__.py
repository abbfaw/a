# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import account_payment_register
from . import payment_link_wizard
from . import payment_refund_wizard
