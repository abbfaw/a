# -*- encoding: utf-8 -*-

from . import account_move
from . import account_journal
from . import account_edi_format
from . import account_edi_document
from . import account_payment
from . import ir_actions_report
from . import mail_template
from . import ir_attachment
from . import uom
