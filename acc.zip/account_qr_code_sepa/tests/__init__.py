# *-* coding:utf-8 *-*

from . import test_sepa_qr