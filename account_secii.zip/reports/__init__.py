# from . import synthese_report
# from . import report_synthese
from . import synthese_report
from . import synthese_xlsx
