/** @odoo-module **/

import { ViewWrapper } from "@web_dashboard/view_wrapper/view_wrapper";
console.log("Le module est chargé")
class ViewWrapperInherit extends ViewWrapper {
	setup() {
		console.log("Heritage reussi");
        useSubEnv(this.props.callbackRecorders);
        useEffect(() => {
            const btns = this.el.querySelectorAll(".btn-primary, .btn-secondary");
            btns.forEach((btn) => {
                btn.classList.remove("btn-primary", "btn-secondary");
                btn.classList.add("btn-outline-danger");
            });
            if (this.props.type === "cohort") {
                this.el
                    .querySelectorAll("[class*=interval_button]")
                    .forEach((el) => el.classList.add("text-muted"));
            }
        });
    }
}

