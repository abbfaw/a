# -*- coding: utf-8 -*-

from . import inherit_sale_order
from . import inherit_res_partner
from . import inherit_stock_picking
from . import inherit_stock_picking_type
from . import inherit_sale_make_invoice_advance
from . import inherit_pucharse
from . import sale_report

