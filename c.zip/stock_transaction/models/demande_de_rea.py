from odoo import api, fields, models, _
from odoo.exceptions import UserError
from odoo.http import request
from odoo.exceptions import ValidationError
from datetime import datetime

PROCUREMENT_PRIORITIES = [('0', 'Normal'), ('1', 'Urgent')]


class DemandeMoveLine(models.Model):
    """
    Ligne de commande
    L'utilisateur pour rajouter plusieurs lignes de produits lors de sa demande
    """
    _name = "demande.move.line"
    _description = "Demande"
    _rec_name = "product_id"
    _check_company_auto = True

    demande_id = fields.Many2one(
        'stock.demande', 'Demande', auto_join=True,
        check_company=True,
        index=True,
        ondelete='cascade',
        help='The stock operation where the packing has been made')
    product_id = fields.Many2one('product.product',
                                 'Article',
                                 check_company=True,
                                 store=True,
                                 ondelete="cascade",
                                 domain="[('type', '!=', 'service'), '|', ('company_id', '=', False), ('company_id', '=', company_id)]")
    product_code = fields.Char(
        related='product_id.code',
        readonly=True)
    product_pdv = fields.Float('PDV TTC',
                               related='product_id.list_price',
                               readonly=True)
    prix_total = fields.Float('Total prix commandé (TTC)', compute="_compte_total_ttc")
    quantite = fields.Float(
        'Quantité commandée', default=0.0,
        required=True, copy=False, digits=(12, 0))
    qtc_totale = fields.Float(
        'Total commandé (unité)', compute="_compte_total")
    qty_done = fields.Float('Done', default=0.0, copy=False, digits=(12, 0))
    product_uom = fields.Many2one('uom.uom', "PCB", related='product_id.uom_po_id', readonly=False)
    quantite_en_stock_pcb = fields.Float(string="En stock (PCB)", compute='_compute_quantite_en_stock_pcb',
                                         readonly=True, digits=(12, 0))
    quantite_en_stock = fields.Float(string="En stock (unité)", digits=(12, 0), compute='_compute_quantite_en_stock', readonly=True)
    incoming_qty_pcb = fields.Float('Stock (PCB) Prévisionnel', digits=(12, 0), index=True, compute='_compute_incoming_qty_pcb',
                                    readonly=True)
    incoming_qty = fields.Float('Stock Prévisionnel', digits=(12, 0), index=True, compute='_compute_incoming_qty', readonly=True)
    product_uom_category_id = fields.Many2one(related='product_id.uom_id.category_id', readonly=True)
    date = fields.Datetime('Date', default=fields.Datetime.now, required=True)
    reference = fields.Char(related='demande_id.name', store=True, related_sudo=False, readonly=False)
    company_id = fields.Many2one(
        'res.company', 'Company', required=True,
        related='demande_id.company_id',
        readonly=True,
        store=True,
        default=lambda s: s.env.company.id, index=True)

    @api.constrains('product_id', 'quantite', 'product_uom')
    def _compute_incoming_qty_pcb(self):
        """
        Calculer la quantité avenir  en pcb
        """
        for move in self:
            move.incoming_qty_pcb = round(move.quantite_en_stock / move.product_uom.factor_inv, 2) + move.quantite

    @api.depends('product_id', 'quantite')
    def _compute_incoming_qty(self):
        """
        Calculer la quantité avenir
        """
        for move in self:
            move.incoming_qty = move.quantite_en_stock + move.qtc_totale

    @api.depends('product_id', 'quantite')
    def _compte_total_ttc(self):
        for move in self:
            move.prix_total = move.qtc_totale * move.product_pdv

    @api.depends('product_id', 'quantite', 'product_uom')
    def _compte_total(self):
        for move in self:
            move.qtc_totale = move.quantite * move.product_uom.factor_inv

    @api.constrains('product_id', 'product_uom')
    def _compute_quantite_en_stock_pcb(self):
        for move in self:
            product = self.env['product.product'].search([('id', '=', move.product_id.id)])
            move.quantite_en_stock_pcb = round(product.qty_available / move.product_uom.factor_inv, 2)

    @api.depends('product_id', 'product_uom')
    def _compute_quantite_en_stock(self):
        for move in self:
            product = self.env['product.product'].search([('id', '=', move.product_id.id)])
            move.quantite_en_stock = product.qty_available

    def _compute_quantities(self):
        res = self._compute_quantities_dict()
        for template in self:
            template.qty_available = res[template.id]['qty_available']


class Demande(models.Model):
    _name = "stock.demande"
    _inherit = ['portal.mixin', 'mail.thread', 'mail.activity.mixin', 'sequence.mixin']
    _order = "scheduled_date desc, id"

    name = fields.Char(
        'Reference',
        default='/',
        readonly=True)
    note = fields.Html('Notes')
    state = fields.Selection([
        ('draft', 'Brouillon'),
        ('confirmed', 'En attente de validation'),
        ('validate', 'Validé'),
        ('cancel', 'Annulée'),
    ], string='Status', default='draft', copy=False, index=True, store=True)
    priority = fields.Selection(
        PROCUREMENT_PRIORITIES, string='Priority', default='0',
        help="Products will be reserved first for the transfers with the highest priorities.")
    scheduled_date = fields.Datetime(
        'Date de commande', store=True,
        track_visibility="onchange",
        index=True, default=fields.Datetime.now,
        states={'done': [('readonly', True)], 'cancel': [('readonly', True)]},
        help="Scheduled time for the first part of the shipment to be processed. Setting manually a value here would set it as expected date for all the stock moves.")
    date_deadline = fields.Datetime(
        "Deadline",
        help="Date Promise to the customer on the top level document (SO/PO)")
    date = fields.Datetime(
        'Creation Date',
        default=fields.Datetime.now,
        states={'done': [('readonly', True)], 'cancel': [('readonly', True)]},
        help="Creation Date, usually the time of the order")
    date_done = fields.Datetime('Date de validation', copy=False, readonly=True,
                                help="Date at which the transfer has been processed or cancelled.")
    company_id = fields.Many2one(
        'res.company', string='Company',
        store=True,
        default=lambda s: s.env.company.id, index=True,
        readonly=True)
    user_id = fields.Many2one(
        'res.users', 'Responsible',
        check_company=True,
        domain=lambda self: [('groups_id', 'in', self.env.ref('stock.group_stock_user').id)],
        states={'done': [('readonly', True)], 'cancel': [('readonly', True)]},
        default=lambda self: self.env.user)
    move_lines = fields.One2many('demande.move.line', 'demande_id',
                                 string="Stock Moves")
    commandes = fields.Text(track_visibility="always", default="")
    active = fields.Boolean(string="Active", default=True)  # permet d'archiver et de desarchiver un objet

    # empêche d'ajouter deux fois le même article
    @api.onchange('move_lines')
    def _onchange_line(self):
        for order in self.move_lines:
            line = self.move_lines.filtered(lambda l: l.product_id == order.product_id)
            if len(line) > 1:
                raise ValidationError(_("Vous avez déjà ajouté l'article (%s) dans la demande !!!") % (line[1].product_id.name))
                break

    @api.model
    def create(self, vals):
        new_demande = super(Demande, self).create(vals)
        vals['commandes'] = self._get_commande()
        vals['move_lines'] = []
        super(Demande, self).write(vals)
        return new_demande

    def write(self, vals):
        super(Demande, self).write(vals)
        vals['commandes'] = self._get_commande()
        vals['move_lines'] = []
        super(Demande, self).write(vals)

    def _get_commande(self):
        commandes = [
            str(i.quantite) + ' packs de ' + str(i.product_id.name) + '\n\n'
            for i in self.move_lines
        ]
        return commandes

    # def action_confirm(self):
    #     """
    #     Générer un code unique pour la demande
    #     """
    #     self.state = 'confirmed'
    #     base = "BC/"
    #     ir_sequence = self.env['ir.sequence']
    #     for rec in self:
    #         if rec.company_id.street:
    #             middle = rec.company_id.street[:3].upper() + "/"
    #         else:
    #             middle = "CMX"
    #         next = str(ir_sequence.next_by_code('demande.name'))
    #         if len(next) == 3:
    #             next = '0' + next
    #         elif len(next) == 2:
    #             next = '00' + next
    #         elif len(next) == 1:
    #             next = '000' + next
    #         rec.name = base + middle + next
    #     return True

    def action_cancel(self):
        self.state = 'cancel'
        return True

    def button_validate(self):
        # self.state = 'validate'
        self.write({'state': 'validate', 'date_done': fields.Datetime.now()})
        """
               Générer un code unique pour la demande 
        """
        base = "BC/"
        ir_sequence = self.env['ir.sequence']
        for rec in self:
            if rec.company_id.street:
                middle = rec.company_id.street[:3].upper() + "/"
            else:
                middle = "CMX"
            next = str(ir_sequence.next_by_code('demande.name'))
            if len(next) == 3:
                next = '0' + next
            elif len(next) == 2:
                next = '00' + next
            elif len(next) == 1:
                next = '000' + next
            rec.name = base + middle + next

            # id de la company actuel
            company_id = rec.company_id

            # récupérer l'entrepôt centrale
            get_entrepot_centrale = request.env['res.company'].sudo().search([('entrepot_centrale', '=', True)])

            # récupérer le type d'opération pour le magasin actuel au niveau de l'entrepôt central
            get_picking_type = request.env['stock.picking.type'].sudo().search(
                [('company_id', '=', get_entrepot_centrale.id),
                 ('code', '=', 'outgoing'),
                 ('entreprise_de_destination_par_defaut', '=',
                  company_id.id)
                 ])
            if not get_picking_type:
                # renvoyer une exception si entrepôt centrale et type d'opération non trouvé
                raise UserError(
                    _("Impossible de confirmer la commande. Vous devez cocher l'entreprise de l'entrepôt principal"))

            # Instancier le transfert
            transfert_obj = self.env["stock.picking"]

            # Données du transfère
            pick = {
                "picking_type_id": get_picking_type[0].id,
                "location_id": get_picking_type[0].default_location_src_id.id,
                # "location_dest_id": get_picking_type[0].entreprise_de_destination_par_defaut.partner_id.id,
                "partner_id": get_picking_type[0].entreprise_de_destination_par_defaut.partner_id.id,
                "move_ids_without_package": [
                    {
                        'name': rec.name,
                        "location_id": get_picking_type[0].default_location_src_id.id,
                        "partner_id": get_picking_type[0].entreprise_de_destination_par_defaut.partner_id.id,
                        # "location_dest_id": get_picking_type[0].entreprise_de_destination_par_defaut.partner_id.id,
                        'product_id': prod.product_id,
                        'product_uom_qty': prod.quantite * prod.product_uom.factor_inv,
                        'product_uom': self.env["uom.uom"].sudo().search([('name', '=', 'Unités')]).id,
                    } for prod in rec.move_lines
                ],
                "scheduled_date": rec.scheduled_date,
                "origin": rec.name,
            }
            transfert_obj = transfert_obj.sudo().create(pick)

            # Valider le partner
            transfert_obj.sudo().onchange_partner_id()

            # Valider le type d'opération
            transfert_obj.sudo()._onchange_picking_type()

            # marquer le transfert à faire
            transfert_obj.sudo().action_confirm()
        return True
