# Transfert inter-entreprise

> *Note:* créer un type d'opération de type Transfert inter-entreprise
> 
> Ce type sera utilisé pour les transfert inter-entreprise
