# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import sale_report
from . import invoice_report
from . import report_all_channels_sales
