# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import account_payment_register
from . import mail_compose_message
from . import payment_acquirer_onboarding_wizard
from . import sale_make_invoice_advance
from . import sale_order_cancel
from . import sale_payment_link
