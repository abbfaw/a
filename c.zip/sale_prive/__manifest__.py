# -*- coding: utf-8 -*-
{
    'name': "sale_prive",

    'summary': """
        specific module""",

    'description': """
        specific module
    """,

    'author': "progistack",
    'website': "http://www.progistack.com",

    'category': 'Uncategorized',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': ['base', 'sale', 'purchase'],

    # always loaded
    'data': [
        'security/secii_sale_security.xml',
        # 'security/ir.model.access.csv',
        'views/inherit_sale_order_view.xml',
        'views/inherit_res_partner.xml',
        'views/inherit_stock_picking.xml',
        'views/inherit_purchase_order_view.xml',

    ],

}
