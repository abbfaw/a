from odoo import api, models, fields
from datetime import datetime, date

class ReportPaie(models.TransientModel):
    _name = "report.cotisation"

    start_date = fields.Date()
    end_date = fields.Date()
    year = fields.Char(string='Année')
    periode = fields.Selection([
        ('1', '1er trimestre'),
        ('2', '2e trimestre'),
        ('3', '3e trimestre'),
        ('4', '4e trimestre'),
        ('year', "l'année"),
    ])

    def confirmer(self):
        year = int(self.year)
        print('year', year)
        start_date = ''
        end_date = ''
        periode = self.periode
        if periode == '1':
            start_date = datetime(year, 1, 1)
            end_date = datetime(year, 3, 31)

        if periode == '2':
            start_date = datetime(year, 4, 1)
            end_date = datetime(year, 6, 30)

        if periode == '3':
            start_date = datetime(year, 7, 1)
            end_date = datetime(year, 9, 30)

        if periode == '4':
            start_date = datetime(year, 10, 1)
            end_date = datetime(year, 12,31)
        if periode == 'year':
            start_date = datetime(year, 1, 1)
            end_date = datetime(year, 12, 31)

        print('periode', start_date, end_date)
        if not start_date and not end_date:
            start_date = self.start_date
            end_date = self.end_date
        contract = self.env['hr.payslip'].search([])
        print('test')
        data = {'start_date': start_date, 'end_date': end_date, 'contract': contract}
        print(data)
        return self.env.ref('hr_payroll.action_report_cotisation').report_action(self, data=data)

    def cancel(self):
        print('cancel')