from odoo import api, models, fields


class ReportPaie(models.TransientModel):
    _name = "report.paie"

    start_date = fields.Date()
    end_date = fields.Date()

    def confirmer(self):

        print('%%%%confirmer')
        start_date = self.start_date
        end_date = self.end_date
        contract = self.env['hr.payslip'].search([])
        print('test')
        data = {'start_date': start_date, 'end_date': end_date, 'contract': contract}
        print(data)
        return self.env.ref('hr_payroll.report_payslip_paie_synthese').report_action(self, data=data)

    def cancel(self):
        print('cancel')
