# -*- coding:utf-8 -*-

from odoo import api, fields, models, _
from datetime import date, datetime
from odoo.exceptions import ValidationError
from math import *


class HrContract(models.Model):
    """
    Employee contract based on the visa, work permits
    allows to configure different Salary structure
    """
    _inherit = 'hr.contract'
    _description = 'Employee Contract'

    struct_id = fields.Many2one('hr.payroll.structure', string='Salary Structure')
    schedule_pay = fields.Selection([
        ('monthly', 'Monthly'),
        ('quarterly', 'Quarterly'),
        ('semi-annually', 'Semi-annually'),
        ('annually', 'Annually'),
        ('weekly', 'Weekly'),
        ('bi-weekly', 'Bi-weekly'),
        ('bi-monthly', 'Bi-monthly'),
    ], string='Scheduled Pay', index=True, default='monthly',
        help="Defines the frequency of the wage payment.")
    resource_calendar_id = fields.Many2one(required=True, help="Employee's working schedule.")
    hra = fields.Monetary(string='HRA', tracking=True, help="House rent allowance.")
    travel_allowance = fields.Monetary(string="Prime Transport", help="Prime Transport", required=True)
    da = fields.Monetary(string="DA", help="Dearness allowance")
    meal_allowance = fields.Monetary(string="Meal Allowance", help="Meal allowance")
    medical_allowance = fields.Monetary(string="Medical Allowance", help="Medical allowance")
    other_allowance = fields.Monetary(string="Other Allowance", help="Other allowances")
    salary = fields.Monetary(string='Salaire de base')
    su_salary = fields.Monetary(string='Sur-Salaire')
    wage = fields.Monetary(string='Salaire brut', required=True, store=True, tracking=True, compute='compute_wage',
                           help="Employee's monthly gross wage.")
    its = fields.Monetary(string='IS', store=True, compute='compute_its')
    cn = fields.Monetary(string='CN', store=True, compute='compute_its')
    pa = fields.Monetary(string='Prime Ancienneté', compute='compute_pa')
    revenue_net_im = fields.Monetary(string='Revenu net imposable', store=True, compute='compute_revenue_net_im')
    r_n = fields.Monetary(string='R/N', store=True, compute='compute_nbr_part')
    igr = fields.Monetary(string='IGR', store=True, compute='compute_igr_value')
    nbr_part = fields.Float(string='Nombre de part', store=True, compute='compute_nbr_part')
    cr = fields.Monetary(string='CNPS', compute='compute_wage')
    net_pay = fields.Monetary(string='Net à payer', compute='compute_net_pay')
    responsibility_bonus = fields.Monetary(string='Prime de responsabilité')
    exceptional_bonus = fields.Monetary(string='Prime exceptionnelle')
    performance_bonus = fields.Monetary(string='Prime de rendement')
    rounding = fields.Monetary(string='Les arrondis')
    cmu = fields.Monetary(compute='compute_cmu')
    current_year = fields.Date()
    contrat_duration = fields.Char(compute='compute_duration', string="Durée ancienneté")
    cmu_patronale = fields.Monetary(compute='compute_cmu')
    basket_bonus = fields.Monetary(string='Prime de Panier')
    hourly_rates = fields.Float(compute='taux_horaire', )
    HS_15 = fields.Float(string='Heures sup à 15%', )
    mount_15 = fields.Monetary(string='Montant HS 15%', compute='taux_horaire', )
    HS_50 = fields.Float(string='Heures sup à 50%', )
    mount_50 = fields.Monetary(string='Montant HS 50%', compute='taux_horaire', )
    HS_75 = fields.Float(string='Heures sup à 75%')
    mount_75 = fields.Monetary(string='Montant HS 75%', compute='taux_horaire', )
    HS_100 = fields.Float(string='Heures sup à 100%', )
    mount_100 = fields.Monetary(string='Montant HS 100%', compute='taux_horaire', )
    taxable_transportation_allowance = fields.Monetary(string='Prime de transport imposable', compute='compute_travel', store=True)
    retenu_absence = fields.Monetary(string='Retenu sur absence')
    Acompte = fields.Monetary(string='Acompte sur salaire')
    salary_advance = fields.Monetary(string='Avance sur salaire')
    Anciennete_horaire = fields.Monetary(string='Anciennete horaire', compute='compute_ha', )
    monthly_salary_recall = fields.Monetary(string='rappel salaire mensuel')
    Licensing_compensation = fields.Monetary(string='indemnité de licencement')
    prime_salissure_imposable = fields.Monetary(string='Prime de salissure imposable')
    paid_vacation = fields.Monetary(string='Congé payé')
    gratification = fields.Monetary(string='Gratification')
    advantage_in_kind = fields.Monetary(string='Avantage en nature')
    other_bonus = fields.Monetary(string='Autre prime')
    retraite_generale = fields.Monetary(string='Retraite generale', compute='compute_cotisation', )
    prestation_familiale = fields.Monetary(string='Prestation familiale', compute='compute_cotisation', )
    taxe_app = fields.Monetary(string='taxe_app', compute='compute_cotisation', )
    taxe_fpc = fields.Monetary(string='taxe_fpc', compute='compute_cotisation', )
    work_related_accident = fields.Monetary(string='Accident de travail', compute='compute_cotisation', )
    taux_work_related_accident = fields.Float(string="taux d'accident de travail", default=2)
    cnps_salariale = fields.Monetary(string='CNPS Salariale', compute='compute_cotisation', )
    method_of_payment = fields.Selection([
        ('espece', 'Espèces'),
        ('cheque', 'Chèque'),
        ('virement', 'Virement Bancaire'),
        ('mobile', 'Mobile Money'),
    ],string="Mode de paiement")
    assurance_maternite = fields.Monetary(string='Assurance maternité',compute='compute_cotisation')
    assurance_maternité = fields.Char()
    indemnite_depart_retraite = fields.Monetary(string='Indemnité de depart à la retraite')
    indemnite_licencement_imposable = fields.Monetary(string='Indemnite de licencement imposable')
    indemnite_licencement = fields.Monetary(string='Indemnite de licencement non imposable')
    daily_pay = fields.Monetary(string='Salaire journalier')
    work_day = fields.Float(string='Nombre de jours travaillés')
    total_journalier = fields.Monetary(string='Total salaire journalier', compute='compute_day')
    round = fields.Monetary(string='Arrondis', compute='compute_net_pay', )
    total_cotisation = fields.Monetary(compute='cotisation')

    @api.depends('its','igr','cn', 'cnps_salariale','cmu','retraite_generale','prestation_familiale', 'assurance_maternite','work_related_accident','taxe_app', 'taxe_fpc')
    def cotisation(self):
        for rec in self:
            rec.total_cotisation = 2 * (rec.its) + rec.igr + rec.cn + rec.cnps_salariale + rec.cmu + rec.retraite_generale + rec.prestation_familiale + rec.assurance_maternite + rec.work_related_accident + rec.taxe_app + rec.taxe_fpc

    @api.depends('daily_pay', 'work_day')
    def compute_day(self):
        for rec in self:
            rec.total_journalier = rec.work_day * rec.daily_pay

    @api.depends('pa')
    def compute_ha(self):
        for rec in self:
            rec.Anciennete_horaire = rec.pa / 173

    @api.depends('wage','taux_work_related_accident')
    def compute_cotisation(self):

        for rec in self:
            rec.retraite_generale = 0.077 * rec.wage
            rec.taxe_app = 0.004 * rec.wage
            rec.taxe_fpc = 0.006 * rec.wage
            rec.prestation_familiale = 0.05 * 75000
            rec.assurance_maternite = 0.0075 * 75000
            rec.work_related_accident = ((rec.taux_work_related_accident)/100) * 75000
            rec.cnps_salariale = 0.063 * rec.wage

    @api.onchange('taux_work_related_accident')
    def taux(self):
        for rec in self:
          if rec.taux_work_related_accident < 2 or rec.taux_work_related_accident > 5:
              raise ValidationError("Le taux d'accident de travail doit etre compris entre 2 et 5%")

    def compute_travel(self):
        for rec in self:
            tp = rec.travel_allowance
            if tp > 30000:
                print('prime imp')
                prime = rec.travel_allowance
                rec.travel_allowance = 30000
                rec.taxable_transportation_allowance = (prime) - (rec.travel_allowance)
            print('taxable', rec.taxable_transportation_allowance)


    @api.depends('salary', 'HS_15', 'HS_50','HS_75', 'HS_100')
    def taux_horaire(self):
        for rec in self:
            rec.hourly_rates = rec.salary / 173.33
            hourly_rates = rec.hourly_rates
            print('hourly', hourly_rates)
            rec.mount_15 = (hourly_rates * 1.15) * rec.HS_15
            print('hs15', rec.mount_15)
            rec.mount_50 = (hourly_rates * 1.50) * rec.HS_50
            print('hs15', rec.mount_50)
            rec.mount_75 = (hourly_rates * 1.75) * rec.HS_75
            print('hs15', rec.mount_75)
            rec.mount_100 = (hourly_rates * 2) * rec.HS_100
            print('hs15', rec.mount_100)


    @api.depends('date_start', 'date_end')
    def compute_duration(self):
        for rec in self:
            start_date = rec.date_start
            end_date = date.today()
            date_diff = end_date - start_date
            years = date_diff.days // 365
            months = (date_diff.days - years * 365) // 30
            rec.contrat_duration = f"{years} An(s) {months} mois"

    @api.onchange('salary',)
    def compute_pa(self):
        prime_pa = 0
        for rec in self:
            debut = rec.date_start.year
            debut = int(debut)
            print('debut', debut)
            today = date.today().year
            today = int(today)
            begin_pa = today - debut
            print("bp", begin_pa)
            if begin_pa >= 2:
                prime_pa = (rec.salary * int(begin_pa)) / 100
            rec.pa = prime_pa
            print('pa', rec.pa)

    @api.onchange('wage',)
    def compute_cmu(self):

        print('%%%% cmucmu')
        cmu_employee = 500
        employee = 0
        cmu_patronale = 500
        for val in self:
            employee = val.employee_id.id
            print('em', employee)
            kids = self.env['hr.kids'].search([('parent','=', employee)])
            if len(kids) <= 6:
                cmu_employee = 500 * len(kids) + 500
                cmu_patronale = cmu_employee
            if len(kids) > 6:
                cmu_extra = len(kids) - 6
                cmu_patronale = 3500
                cmu_employee = 500 * 7 + cmu_extra * 1000
            val.cmu = cmu_employee
            val.cmu_patronale = cmu_patronale
            print('cmu',val.cmu)

    @api.depends('exceptional_bonus','performance_bonus', 'su_salary', 'salary', 'responsibility_bonus','pa', 'basket_bonus', 'Licensing_compensation','paid_vacation', 'gratification', 'taxable_transportation_allowance', 'prime_salissure_imposable', 'mount_15','mount_50','mount_75','mount_100', 'indemnite_depart_retraite', 'daily_pay', 'work_day','advantage_in_kind',)
    def compute_wage(self):
        for value in self:
            value.wage = value.exceptional_bonus + value.performance_bonus + value.advantage_in_kind + value.salary + value.su_salary + value.responsibility_bonus + value.pa + value.basket_bonus + value.Licensing_compensation + value.paid_vacation + value.gratification + value.taxable_transportation_allowance + value.prime_salissure_imposable + value.mount_15 + value.mount_50 + value.mount_75 + value.mount_100 + value.indemnite_depart_retraite + (value.work_day * value.daily_pay)
            value.cr = (value.wage * 6.3) / 100

    @api.depends('its', 'cn', 'igr', 'cr', 'wage', 'travel_allowance', 'exceptional_bonus', 'other_bonus','exceptional_bonus','retenu_absence','Acompte', 'salary_advance','monthly_salary_recall','indemnite_licencement')
    def compute_net_pay(self):
        for value in self:
            value.net_pay = value.travel_allowance + value.wage - (value.cr + value.igr + value.its + value.cn + value.cmu + value.salary_advance + value.retenu_absence) + value.other_bonus + value.Acompte + value.monthly_salary_recall + value.indemnite_licencement
            net = value.net_pay
            value.net_pay = (ceil(value.net_pay/1000)*1000)
            value.round = value.net_pay - net

    @api.depends('wage')
    def compute_its(self):
        for val in self:
            val.its = (val.wage * 1.2) / 100
            if val.wage * 0.8 < 50000:
                val.cn = 0
            elif val.wage * 0.8 < 130000:
                val.cn = (val.wage * 0.8) * 0.015 - 750
            elif val.wage * 0.8 < 200000:
                val.cn = (val.wage * 0.8) * 0.05 - 5300
            else:
                val.cn = (val.wage * 0.8) * 0.1 - 15300

    @api.depends('its', 'cn')
    def compute_revenue_net_im(self):
        for val in self:
            val.revenue_net_im = ((val.wage * 0.8) - (val.its + val.cn)) * 0.85

    @api.depends('revenue_net_im', 'salary')
    def compute_nbr_part(self):
        for val in self:
            n = 0
            if val.employee_id.marital == 'married':
                n += 2
                n += int(val.employee_id.children) * 0.5
            if val.employee_id.marital == 'single':
                if val.employee_id.children > 0:
                    n += 1.5
                    n += 0.5 * int(val.employee_id.children)
                else:
                    n = 1
            if val.employee_id.marital == 'widower':
                n += 2
            if val.employee_id.marital == 'divorced':
                n += 2
            print('nnnnnnnnnnnn',n)
            if n != 0:
                val.r_n = val.revenue_net_im / n
                val.nbr_part = n

    @api.depends('r_n', 'wage')
    def compute_igr_value(self):
        data = [{'c': 1, 'min': 0, 'max': 25000}, {'c': 2, 'min': 25000, 'max': 45583},
                {'c': 3, 'min': 45583, 'max': 81583},
                {'c': 4, 'min': 81583, 'max': 126583}, {'c': 5, 'min': 126583, 'max': 220333},
                {'c': 6, 'min': 220333, 'max': 389083},
                {'c': 7, 'min': 389083, 'max': 842166}, {'c': 8, 'min': 842167, 'max': 1}]
        for val in self:
            c = 0
            r_n = val.r_n
            for da in data:
                if float(da['min']) <= r_n <= float(da['max']):
                    c = da['c']
                if float(da['min']) <= r_n and float(da['max']) == 1:
                    c = da['c']
            if c == 1:
                val.igr = 0
            if c == 2:
                val.igr = (val.revenue_net_im * (10 / 110)) - 2273 * val.nbr_part
            if c == 3:
                val.igr = (val.revenue_net_im * (15 / 115)) - 4076 * val.nbr_part
            if c == 4:
                val.igr = (val.revenue_net_im * (20 / 120)) - 7031 * val.nbr_part
            if c == 5:
                val.igr = (val.revenue_net_im * (25 / 125)) - 11250 * val.nbr_part
            if c == 6:
                val.igr = (val.revenue_net_im * (35 / 135)) - 24306 * val.nbr_part
            if c == 7:
                val.igr = (val.revenue_net_im * (45 / 145)) - 44181 * val.nbr_part
            if c == 8:
                val.igr = (val.revenue_net_im * (60 / 160)) - 98633 * val.nbr_part

    @api.onchange('su_salary')
    def onchange_su_salary(self):
        if self.su_salary < 0:
            warning_mess = {
                'title': _('Avertissement!'),
                'message': _("Le sur-salaire ne doit pas être négatif")
            }
            self.su_salary = 0
            return {'warning': warning_mess}

    @api.onchange('salary')
    def onchange_salary(self):
        if self.salary < 0:
            warning_mess = {
                'title': _('Avertissement!'),
                'message': _("Le salaire ne doit pas être négatif")
            }
            self.salary = 0
            return {'warning': warning_mess}

    def get_all_structures(self):

        """
        @return: the structures linked to the given contracts, ordered by hierachy (parent=False first,
                 then first level children and so on) and without duplicata
        """
        structures = self.mapped('struct_id')
        if not structures:
            return []
        # YTI TODO return browse records
        return list(set(structures._get_parent_structure().ids))

    def get_attribute(self, code, attribute):

        return self.env['hr.contract.advantage.template'].search([('code', '=', code)], limit=1)[attribute]

    @api.model
    def create(self, vals_list):
        vals_list['wage'] = self.wage
        res = super(HrContract, self).create(vals_list)
        return res

    def set_attribute_value(self, code, active):
        for contract in self:

            if active:

                value = self.env['hr.contract.advantage.template'].search([('code', '=', code)], limit=1).default_value
                contract[code] = value
            else:

                contract[code] = 0.0


class HrContractAdvandageTemplate(models.Model):
    _name = 'hr.contract.advantage.template'
    _description = "Employee's Advantage on Contract"

    name = fields.Char('Name', required=True)
    code = fields.Char('Code', required=True)
    lower_bound = fields.Float('Lower Bound', help="Lower bound authorized by the employer for this advantage")
    upper_bound = fields.Float('Upper Bound', help="Upper bound authorized by the employer for this advantage")
    default_value = fields.Float('Default value for this advantage')


class ResCompany(models.Model):
    _inherit = 'res.company'

    number_cnps = fields.Char(string="Numéro CNPS")
