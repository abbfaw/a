#-*- coding:utf-8 -*-

from . import report_payslip_details
from . import report_contribution_register
from . import synthese_paie
from . import synthese_cotisation_report
