from odoo import fields, models, api


class ProductTemplate(models.Model):
	_inherit = "product.template"

	# Rétourner uniquement les udm qui sont des references
	def _get_uom_domain(self):

		uom_references = []
		for category_id in self.env['uom.category'].search([]):
			uom_id = self.env['uom.uom'].search([('category_id', '=', category_id.id), ('uom_type', '=', 'reference')])
			if uom_id:
				uom_references.append(uom_id.id)

		return "[('id', 'in', %s)]"%(uom_references,)

	# Champ permettant l'attribution d'une unité de mésure unique à l'article
	uom_variant_ids = fields.One2many('uom.uom', 'product_tmpl_id', string="Unités de mésures variantes")
	uom_category_id = fields.Many2one(related='uom_id.category_id')
	uom_id = fields.Many2one('uom.uom', domain=_get_uom_domain)

	standard_price = fields.Float(default=1)
