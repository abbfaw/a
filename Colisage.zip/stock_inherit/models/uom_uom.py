from odoo import fields, models, tools

class UomUom(models.Model):
	_inherit = 'uom.uom'

	product_tmpl_id = fields.Many2one('product.template')
	is_uom_variant_id = fields.Boolean("Est une udm variante")
