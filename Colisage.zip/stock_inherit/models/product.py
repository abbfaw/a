from odoo import fields, models


class ProductProduct(models.Model):
	_inherit = "product.product"

	uom_variant_ids = fields.One2many(related='product_tmpl_id.uom_variant_ids')