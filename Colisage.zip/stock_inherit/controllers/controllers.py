# -*- coding: utf-8 -*-
# from odoo import http


# class StockInherit(http.Controller):
#     @http.route('/stock_inherit/stock_inherit', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/stock_inherit/stock_inherit/objects', auth='public')
#     def list(self, **kw):
#         return http.request.render('stock_inherit.listing', {
#             'root': '/stock_inherit/stock_inherit',
#             'objects': http.request.env['stock_inherit.stock_inherit'].search([]),
#         })

#     @http.route('/stock_inherit/stock_inherit/objects/<model("stock_inherit.stock_inherit"):obj>', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('stock_inherit.object', {
#             'object': obj
#         })
