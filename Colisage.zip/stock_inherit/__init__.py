# -*- coding: utf-8 -*-

from . import controllers
from . import models
from odoo import api, SUPERUSER_ID

# Création de la catégorie des udm variantes
def _create_uom_category(env):

	variant_id = env['uom.category'].search([('is_uom_category_variant_id', '=', True)])
	if not variant_id:
		category_id = env['uom.category'].create({
			'name': "Catégorie des udm variantes",
			'is_uom_category_variant_id': 1
			})
		env['uom.uom'].create({
				'name': "Unité",
				'factor': 1.0,
				'is_uom_variant_id': 1,
				'category_id': category_id.id
			})



def _post_init_hook(cr, registry):

	env = api.Environment(cr, SUPERUSER_ID, {})
	_create_uom_category(env)