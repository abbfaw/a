from odoo import fields, models, tools

class UomUomInherit(models.Model):
	_inherit = 'uom.uom'

	product_uom_domain_sale_id = fields.Many2one('sale.order.line')
