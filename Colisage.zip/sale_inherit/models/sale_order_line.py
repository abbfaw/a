from odoo import fields, api, models


class SaleOrderLineInherit(models.Model):
	_inherit = 'sale.order.line'

	@api.onchange('product_id', 'product_uom_qty', 'product_uom')
	def _compute_puom_d(self):
		for rec in self:
			# print("Le compute", rec, rec._origin, type(rec), type(rec._origin))
			if rec.product_id:
				uom_variant_ids = rec.product_id.uom_variant_ids
				if uom_variant_ids:
					domain = self.env['uom.uom'].search([
						('category_id', '=', rec.product_id.product_tmpl_id.uom_id.category_id.id),
						'|',
						('product_tmpl_id', '=', rec.product_id.product_tmpl_id.id),
						('uom_type', '=', 'reference')
						])
					rec.product_uom_domain = [d.id for d in domain]
					print("Affectation ok", domain, rec.product_uom_domain)
				else:
					print("False 1")
					rec.product_uom_domain = False
			else:
				print("False 2")
				rec.product_uom_domain = False

	product_uom = fields.Many2one('uom.uom', domain="[]")
	product_uom_domain = fields.One2many('uom.uom', 'product_uom_domain_sale_id')