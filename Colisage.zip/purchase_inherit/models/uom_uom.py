from odoo import fields, models, tools

class UomUom(models.Model):
	_inherit = 'uom.uom'

	product_uom_domain_purchase_id = fields.Many2one('purchase.order.line')
