# -*- coding: utf-8 -*-
#############################################################################
#
#    Copyright (C) 2023- Progistack (<https://www.progistack.com>)
#
#############################################################################

{
    "name": "Theme Progistack Odoo 16",
    "description": """Theme Progistack Odoo 16""",
    "summary": "Theme Progistack",
    "category": "Themes/Backend",
    "version": "16.0.1.0.0",
    'author': 'Abdoulaye Coulibaly',
    'company': 'Progistack',
    'website': "https://www.progistack.com",
    "depends": ['base', 'web', 'mail'],
    "data": [
        'views/style.xml',
        'views/res_config_settings.xml',
    ],
    'assets': {
        'web.assets_backend': [
            'progistack_theme/static/src/components/app_menu/side_menu.xml',
            'progistack_theme/static/src/layout/style/login.scss',
            'progistack_theme/static/src/layout/style/layout_colors.scss',
            'progistack_theme/static/src/components/app_menu/menu_order.css',
            'progistack_theme/static/src/layout/style/layout_style.scss',
            'progistack_theme/static/src/layout/style/sidebar.scss',
            'progistack_theme/static/src/components/app_menu/search_apps.js',
        ],
    },
    'images': [
        'static/description/icon.png',
        'static/sr/img/background.jpg'
    ],
    'license': 'LGPL-3',
    'installable': True,
    'application': True,
    'auto_install': False,
    'sequence': -500,
}
