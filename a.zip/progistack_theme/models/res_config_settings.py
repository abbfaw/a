import base64
from odoo import models, fields
from odoo import modules


def get_default_img():
    with open(modules.get_module_resource('progistack_theme', 'static/src/img', 'background.jpg'), 'rb') as f:
        return base64.b64encode(f.read())


class ResCompany(models.Model):
    _inherit = 'res.company'

    background_image = fields.Binary(string="Image de fond", attachment=True, default='get_default_img')


class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    theme_background = fields.Binary(string="Image de fond du menu",
                                     related='company_id.background_image',
                                     readonly=False)
    appbar_text = fields.Char(string="Texte du menu de l'application",
                              config_parameter='progistack_theme.appbar_text',
                              default='#000000')
    secoundary_hover = fields.Char(string="Survol de la barre d'application",
                                   config_parameter='progistack_theme.secoundary_hover',
                                   default='#F2F2F3')
    primary_accent = fields.Char(string="Arrière-plan de la barre de navigation",
                                 config_parameter='progistack_theme.primary_accent_color',
                                 default='#004589')
    secondary_accent = fields.Char(string="Bordure principale",
                                   config_parameter='progistack_theme.secondary_color',
                                   default='#0C4D9D')
    kanban_bg_color = fields.Char(string="Arrière-plan Kanban",
                                  config_parameter='progistack_theme.kanban_bg_color',
                                  default='#F7F7F7')
    primary_hover = fields.Char(string="Survol du bouton principal",
                                config_parameter='progistack_theme.primary_hover',
                                default='#00376E')

    app_bar_color = fields.Char(string="Arrière-plan de la barre d'applications",
                                config_parameter='progistack_theme.appbar_color',
                                default='#FFFFFF')
    light_hover = fields.Char(string="Light Hover",
                              config_parameter='progistack_theme.light_hover',
                              default='#ffffff')

    def config_color_settings(self):
        colors = {}
        colors['full_bg_img'] = self.env.user.company_id.background_image
        colors['appbar_color'] = self.env['ir.config_parameter'].sudo().get_param('progistack_theme.appbar_color')
        colors['primary_accent'] = self.env['ir.config_parameter'].sudo().get_param('progistack_theme.primary_accent_color')
        colors['secondary_color'] = self.env['ir.config_parameter'].sudo().get_param('progistack_theme.secondary_color')
        colors['kanban_bg_color'] = self.env['ir.config_parameter'].sudo().get_param('progistack_theme.kanban_bg_color')
        colors['primary_hover'] = self.env['ir.config_parameter'].sudo().get_param('progistack_theme.primary_hover')
        colors['light_hover'] = self.env['ir.config_parameter'].sudo().get_param('progistack_theme.light_hover')
        colors['appbar_text'] = self.env['ir.config_parameter'].sudo().get_param('progistack_theme.appbar_text')
        colors['secoundary_hover'] = self.env['ir.config_parameter'].sudo().get_param('progistack_theme.secoundary_hover')

        return colors
