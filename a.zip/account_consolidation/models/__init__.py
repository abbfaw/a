# -*- coding: utf-8 -*-

from . import account_account
from . import res_company
from . import account_move
from . import consolidation_coa
from . import consolidation_period
from . import consolidation_journal
from . import consolidation_rate
