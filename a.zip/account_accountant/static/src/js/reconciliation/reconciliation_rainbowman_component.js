/** @odoo-module */

const { Component } = owl;

export class ReconciliationRainbowManComponent extends Component {}

ReconciliationRainbowManComponent.template = "reconciliation.done";
