/** @odoo-module **/

import { registry } from "@web/core/registry";
import { useAutofocus, useService } from "@web/core/utils/hooks";
import { sprintf } from "@web/core/utils/strings";

// const { Component, useState } = owl;
import { AddToBoard } from "@board/weracf/add_to_board/add_to_board";
const favoriteMenuRegistry = registry.category("favoriteMenu");

class AddToBoardInherit extends AddToBoard {

	async addToBoard() {
        const { domain } = this.env.searchModel;
        const { context } = this.env.searchModel.getIrFilterValues();
        const contextToSave = {
            ...context,
            orderedBy: this.env.searchModel.orderBy,
            dashboard_merge_domains_contexts: false,
        };
        console.log("Le model 2", this.env.searchModel.resModel)
        const result = await this.rpc("/board/add_to_dashboard", {
            action_id: this.env.config.actionId,
            context_to_save: contextToSave,
            domain,
            name: this.state.name,
            view_mode: this.env.config.viewType,
        });

        if (result) {
            this.notification.add(
                this.env._t("Please refresh your browser for the changes to take effect."),
                {
                    title: sprintf(this.env._t(`"%s" added to dashboard`), this.state.name),
                    type: "warning",
                }
            );
            this.state.name = this.env.config.displayName;
        } else {
            this.notification.add(this.env._t("Could not add filter to dashboard"), {
                type: "danger",
            });
        }
    }
}

const addToBoardItem = {
    Component: AddToBoardInherit,
    groupNumber: 4,
    isDisplayed: ({ config }) => config.actionType === "ir.actions.act_window",
};

favoriteMenuRegistry.add("add-to-board", addToBoardItem, { sequence: 10 });
