/** @odoo-module **/

import { GraphView } from "@web/views/graph/graph_view";
import { registry } from "@web/core/registry";

console.log("Le js est chargé");
const viewRegistry = registry.category("views");


class DashboardGraphView extends GraphView {
	// console.log("Le New DDV");

}

console.log("DashboardGraphView composant", DashboardGraphView.props)
DashboardGraphView.template = "dashboard.GraphView";
DashboardGraphView.buttonTemplate = "dashboard.GraphView.Buttons";

viewRegistry.add('graph_dashboard', DashboardGraphView);