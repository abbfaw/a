odoo.define('dashboard.ProgistackDashboardAction', function (require) {
	"use_strict";

	console.log("Module dashboard charge");

	var AbstractAction = require('web.AbstractAction');
	var ControlPanel = require('web.ControlPanel');
	var core = require('web.core');
	// var GraphView = require('web.GraphView');

	var ProgistackDashboardAction = AbstractAction.extend({
		template: "progistack.ProgistackDashboardAction",
		// components: { GraphView },
		init: function (){
			console.log("Dans le init");

			this._super.apply(this, arguments);
		}
	});

	core.action_registry.add('action_progistack_dashboard', ProgistackDashboardAction);

	return ProgistackDashboardAction;
});