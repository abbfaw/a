# -*- coding: utf-8 -*-

from . import models
from . import secii_comptable
from . import inherit_account_move_payment
from . import inherit_acount_tax
from . import secii_encaissement
from . import taux_commission
from . import secii_commission
from . import secii_calcule
from . import box_yop
from . import rapport_secii
from . import releve_client
from . import whatsapp
from . import dashboard
