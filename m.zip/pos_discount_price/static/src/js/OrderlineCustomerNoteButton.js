odoo.define('matarshop_reports.MyOrderline', function (require) {
    'use strict';

    const Registries = require('point_of_sale.Registries');
    const { Orderline } = require('point_of_sale.models');

    const MyOrderline = (Orderline) => class MyOrderline extends Orderline {

        set_unit_price(price) {
            super.set_unit_price(price);
        }

        set_discount_amount(amount) {
            if (this.product.lst_price) {
                const tax_value = this.get_all_prices(this.quantity).tax;
                this.discount_amount = amount;
                if (tax_value > 0) {
                    const anover = Math.max(this.get_all_prices(this.quantity).priceWithTax - parseInt(amount), 0);
                    if (this.quantity == 1) {
                        const price = anover;
                        //const price = Math.max((100/118)* anover, 0);
                        this.set_unit_price(price);
                    } else if (this.quantity > 1) {
                        const price = Math.max(anover/this.quantity, 0);
                        this.set_unit_price(price);
                    }
                } else if (tax_value == 0) {
                    if (this.quantity == 1) {
                        const price = Math.max(this.product.lst_price - amount, 0);
                        this.set_unit_price(price);
                    } else if (this.quantity > 1) {
                        const anover = Math.max(this.get_all_prices(this.quantity).priceWithTax - parseInt(amount), 0);
                        const price = Math.max(anover/this.quantity, 0);
                        this.set_unit_price(price);
                    }
                }
            }
        }

        get_discount_amount() {
            return this.discount_amount;
        }
    }
    Registries.Model.extend(Orderline, MyOrderline);
});
