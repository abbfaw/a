odoo.define('matarshop_reports.PosDiscountAmountButton', function (require) {
    'use strict';

    const { useListener } = require("@web/core/utils/hooks");
    const ProductScreen = require('point_of_sale.ProductScreen');
    const PosComponent = require('point_of_sale.PosComponent');
    const Registries = require('point_of_sale.Registries');

    class PosDiscountAmountButton extends PosComponent {
        setup() {
            super.setup();
            useListener('click', this.onClick);
        }

        async onClick() {
            var self = this;
            const { confirmed, payload } = await this.showPopup('NumberPopup', {
                title: this.env._t('Remise en montant'),
                startingValue: 0,
                confirmText: this.env._t('Apply'),
                cancelText: this.env._t('Cancel'),
                inputDescription: this.env._t('Discount Amount'),
            });
            if (confirmed) {
                const orderline = this.env.pos.get_order().get_selected_orderline();
                if (orderline) {
                    orderline.set_discount_amount(payload);
                }
            }
        }
    }
    PosDiscountAmountButton.template = 'PosDiscountAmountButton';

    ProductScreen.addControlButton({
        component: PosDiscountAmountButton,
    });


    Registries.Component.add(PosDiscountAmountButton);

    return PosDiscountAmountButton;
});
