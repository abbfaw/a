odoo.define('matarshop_reports.receipt', function (require) {
"use strict";

var { Orderline } = require('point_of_sale.models');
const Registries = require('point_of_sale.Registries');


const L10nInOrderline = (Orderline) => class L10nInOrderline extends Orderline {
    export_for_printing() {
        var line = super.export_for_printing(...arguments);
        line.discount_amount = this.discount_amount;
        return line;
    }
}
Registries.Model.extend(Orderline, L10nInOrderline);

});
