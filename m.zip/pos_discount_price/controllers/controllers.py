# -*- coding: utf-8 -*-
# from odoo import http


# class PosDiscountPrice(http.Controller):
#     @http.route('/pos_discount_price/pos_discount_price', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/pos_discount_price/pos_discount_price/objects', auth='public')
#     def list(self, **kw):
#         return http.request.render('pos_discount_price.listing', {
#             'root': '/pos_discount_price/pos_discount_price',
#             'objects': http.request.env['pos_discount_price.pos_discount_price'].search([]),
#         })

#     @http.route('/pos_discount_price/pos_discount_price/objects/<model("pos_discount_price.pos_discount_price"):obj>', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('pos_discount_price.object', {
#             'object': obj
#         })
