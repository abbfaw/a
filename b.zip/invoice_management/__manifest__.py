# -*- coding: utf-8 -*-
{
    'name': "Invoice Management",
    'summary': """
        Personnalisation des factures Elka Service""",
    'description': """
        Personnalisation des factures clients et fournisseurs pour la société Elka Service
    """,
    'author': "Tano Martin",
    'website': "http://www.progistack.com",
    'category': 'Project Management',
    'version': '1.0.0',
    'depends': ['base', 'account_accountant', 'stock', 'contacts'],
    'data': [
        'views/views.xml',
        'reports/header_footer.xml',
        'reports/inherit_report_invoice_with_payments.xml',
    ],
    'installable': True,
    'application': True,
    'auto_install': False,
    'sequence': -60,

}
