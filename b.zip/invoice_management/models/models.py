# -*- coding: utf-8 -*-

from odoo import models, fields, api


class InheritAccountMove(models.Model):
    _inherit = 'account.move'

    borderau = fields.Boolean(string='Bon de livraison')
    num_borderau = fields.Char(string='Numéro BL')
    nom_vendeur = fields.Char(string='Vendeur')
