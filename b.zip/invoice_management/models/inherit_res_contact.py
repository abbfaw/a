from odoo import models, fields, api


class ContactResPartnerInherit(models.Model):
    _inherit = 'res.partner'

    delivery_man = fields.Char(string="RC")

