## odoo

### Compatbilité 

```
PERSONNALISATION DE FACTURE CLIENT / FOURNISSEUR

Ce module permet de personnaliser les factures clients / fournisseurs selon la demande de l'entreprise client.
Elle fournit une facture sans entête
```

### Exécution du module

` Se rendre sur une facture clients / fournisseur dans le mondule Comptabilité puis dans l'onglet client / fournisseur `
* 1ère étape
<img src="/static/demo/etape1.PNG" alt="Etape 1"/>
* 2ème étape
<img src="/static/demo/etape2.PNG" alt="Etape 2"/>
* 3ème étape
<img src="/static/demo/etape3.PNG" alt="Etape 3"/>
* 4ème étape
<img src="/static/demo/etape4.PNG" alt="Etape 4"/>
* 5ème étape
<img src="/static/demo/etape5.PNG" alt="Etape 5"/>
 