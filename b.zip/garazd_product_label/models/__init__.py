from . import inherit_product
