from odoo import fields, api, models


class InheritProduct(models.Model):
    _inherit = 'product.product'

    date = fields.Date(string='Date', compute='get_update_price_date')
    default_price_liste = fields.Integer("Price", compute="_compute_variant_item")

    def _compute_variant_item(self):
        for product in self:
            domain = ['|',
                      '&', ('product_tmpl_id', '=', product.product_tmpl_id.id), ('applied_on', '=', '1_product'),
                      '&', ('product_id', '=', product.id), ('applied_on', '=', '0_product_variant')]

            if self.env['product.pricelist.item'].search(domain, limit=1):
                product.default_price_liste = int(self.env['product.pricelist.item'].search(domain, limit=1).price.rsplit(' ')[0].replace('\xa0', ''))
            else:
                product.default_price_liste = 0


    @api.depends('create_date')
    def get_update_price_date(self):
        data = self.env['product.product'].search([])
        for val in data:
            val.sudo().write({"date": val.create_date})
