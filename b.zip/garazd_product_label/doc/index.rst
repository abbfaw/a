**Changelog**
------------------------------

**15.0.1.0.1** 2022-02-04

- Add the label option "Border width"

- Add the label option "Human readable barcode"

**15.0.1.0.0** 2021-12-08

- Migration from 14.0


