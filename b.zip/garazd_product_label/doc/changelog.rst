.. _changelog:

Changelog
=========

`15.0.1.0.1`
------------

- Add the label option "Border width"

- Add the label option "Human readable barcode"

`15.0.1.0.0`
------------

- Migration from 14.0


