# -*- coding: utf-8 -*-
{
    'name': "Permission Manager",
    'summary': """Gestion de permission de stock""",
    'description': """ Gestion de permission de stock
    """,
    'author': "Tano Martin",
    'website': "http://www.progistack.com",
    'category': 'acces',
    'version': '1.0.0',
    'depends': ['base', 'product', 'stock'],
    'data': [
        'security/security.xml',
        # 'security/ir.model.access.csv',
        'views/views.xml',
    ],
    'application': True,
    'sequence': -8,

}
