# -*- coding: utf-8 -*-
from odoo import fields, api, models
from odoo.exceptions import ValidationError


class InheritProductProduct(models.Model):
    _inherit = "product.product"

    standard_price = fields.Float(
        'Cost', company_dependent=False,
        digits='Product Price',
        groups="base.group_user",
        help="""In Standard Price & AVCO: value of the product (automatically computed in AVCO).
        In FIFO: value of the next unit that will leave the stock (automatically computed).
        Used to value the product when the purchase cost is not known (e.g. inventory adjustment).
        Used to compute margins on sale orders.""")


class InheritProductTemplate(models.Model):
    _inherit = "product.template"

    marge = fields.Float(string='Marge', digits=(12, 2), compute='_compute_marge')
    pourcentage_marge = fields.Char(string="pourcentage", readonly=True)

    @api.depends("standard_price", "taxes_id", "list_price")
    def _compute_marge(self):
        for record in self:
            res = record.taxes_id.compute_all(record.list_price)
            montant_ttc = res['total_included']
            if record.list_price == 0:
                record.marge = record.list_price - record.standard_price
            else:
                record.marge = montant_ttc - record.standard_price

            if record.standard_price != 0:
                record.pourcentage_marge = "(= {0:.2f}%)".format((record.marge / record.standard_price) * 100)
            else:
                record.pourcentage_marge = ""
                record.marge = 0

    # @api.model
    # def create(self, vals):
    #     compagnie_active = self.env.company.id
    #
    #     # empêche la création d'article si la compagnie n'est pas Kaderim
    #     if compagnie_active != 1:
    #         raise ValidationError("Assurez-vous d'être sur KADERIM pour créer un article !!!")
    #     res = super(InheritProductTemplate, self).create(vals)
    #     return res
