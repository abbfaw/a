Odoo All in One Hide/Enable Buttons | Disable Action Button | Disable Print Button | Disable Create Button | Disable Delete Button | Disable Edit Button | Disable Export Button
================================================================================================================================================================================
- This app helps you hide the Action/print, Create, Delete, Edit, and Export buttons for specific users.

Installation
============
- Copy disable_create_edit_globally module to addons folder
- Install the module normally like other modules.