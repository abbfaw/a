from odoo import http
from odoo.http import request
from odoo.tools.translate import _


class ActivitiesDashboard(http.Controller):

    @http.route('/disable_create_edit_globally/get_roles_data', type="json", auth='user')
    def get_roles_details(self):
        has_system_access = False
        has_create_access = False
        has_edit_access = False
        has_delete_access = False
        has_export_access = False
        has_action_access = False

        if request.env.user:
            has_system_access = request.env.user.has_group('base.group_system')
            has_create_access = request.env.user.has_group('disable_create_edit_globally.group_disable_create_access')
            has_edit_access = request.env.user.has_group('disable_create_edit_globally.group_disable_edit_form_access')
            has_delete_access = request.env.user.has_group('disable_create_edit_globally.group_disable_delete_access')
            has_export_access = request.env.user.has_group('disable_create_edit_globally.group_disable_export_access')
            has_action_access = request.env.user.has_group('disable_create_edit_globally.group_disable_action_access')

        results = {
            'has_system_access': has_system_access,
            'has_create_access': has_create_access,
            'has_edit_access': has_edit_access,
            'has_delete_access': has_delete_access,
            'has_export_access': has_export_access,
            'has_action_access': has_action_access,
        }
        return results
