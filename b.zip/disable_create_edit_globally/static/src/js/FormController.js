odoo.define("disable_create_edit_globally.FormController", function(require) {
    "use strict";

    var FormController = require('web.FormController');

    FormController.include({
        
        willStart: function () {
            var self = this;
            var user_role_deferred = $.Deferred();
            var prom = this._rpc({
                route: '/disable_create_edit_globally/get_roles_data',                
            });
            prom.then(function (result) {
                self.hasGroupSystem = result.has_system_access;
                self.hasGroupCreate = result.has_create_access;
                self.hasGroupEdit = result.has_edit_access;
                self.hasGroupDelete = result.has_delete_access;                                
                self.hasGroupAction = result.has_action_access;                                
                user_role_deferred.resolve();
            });
            return Promise.all([this._super(...arguments), prom]).then(function(){
                if (!self.hasGroupSystem){
                    if (self.hasGroupCreate){
                        self.activeActions.create = !self.hasGroupCreate;                         
                    }
                    if(self.hasGroupEdit){                       
                        self.activeActions.edit = !self.hasGroupEdit; 
                    }
                    if (self.hasGroupDelete){
                        self.activeActions.delete = !self.hasGroupDelete; 
                    }
                    if (self.hasGroupAction){
                        self.hasActionMenus = !self.hasGroupAction; 
                    }
                }
            });
        },
    })
});