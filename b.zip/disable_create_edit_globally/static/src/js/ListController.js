odoo.define("disable_create_edit_globally.ListController", function(require) {
    "use strict";

    var ListController = require('web.ListController');

    ListController.include({
        
        willStart: function () {
            var self = this;
            var user_role_deferred = $.Deferred();
            var prom = this._rpc({
                route: '/disable_create_edit_globally/get_roles_data',                
            });
            prom.then(function (result) {
                self.hasGroupSystem = result.has_system_access;
                self.hasGroupCreate = result.has_create_access;
                self.hasGroupEdit = result.has_edit_access;
                self.hasGroupDelete = result.has_delete_access;
                self.hasGroupExport = result.has_export_access;
                self.hasGroupAction = result.has_action_access;
                user_role_deferred.resolve();
            });
            return Promise.all([this._super(...arguments), prom]).then(function(){
                if (!self.hasGroupSystem){
                    if (self.hasGroupCreate){
                        self.activeActions.create = !self.hasGroupCreate; 
                    }
                    if(self.hasGroupEdit){                       
                        self.activeActions.edit = !self.hasGroupEdit; 
                    }
                    if (self.hasGroupDelete){
                        self.activeActions.delete = !self.hasGroupDelete; 
                    }
                    if (self.hasGroupExport){
                        self.activeActions.export_xlsx = !self.hasGroupExport; 
                        self.isExportEnable = !self.hasGroupExport; 
                    }
                    if (self.hasGroupAction){
                        self.hasActionMenus = !self.hasGroupAction; 
                    }
                }                
            });
        },
    })
});
