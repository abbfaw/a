odoo.define("disable_create_edit_globally.KanbanController", function(require) {
    "use strict";

    var KanbanController = require('web.KanbanController');

    KanbanController.include({
        
        willStart: function () {
            var self = this;
            var user_role_deferred = $.Deferred();
            var prom = this._rpc({
                route: '/disable_create_edit_globally/get_roles_data',                
            });
            prom.then(function (result) {
                self.hasGroupSystem = result.has_system_access;
                self.hasGroupCreate = result.has_create_access;
                user_role_deferred.resolve();
            });
            return Promise.all([this._super(...arguments), prom]).then(function(){
                if (!self.hasGroupSystem){
                    if (self.hasGroupCreate){
                        self.activeActions.create = !self.hasGroupCreate; 
                    }
                }
            });
        },
    })
});
