# -*- coding: utf-8 -*-
#################################################################################
# Author      : CFIS (<https://www.cfis.store/>)
# Copyright(c): 2017-Present CFIS.
# All Rights Reserved.
#
#
#
# This program is copyright property of the author mentioned above.
# You can`t redistribute it and/or modify it.
#
#
# You should have received a copy of the License along with this program.
# If not, see <https://www.cfis.store/>
#################################################################################

{
    "name": "Odoo All in One Hide/Enable Buttons | Disable Action Button | Disable Print Button | Disable Create Button | Disable Delete Button | Disable Edit Button | Disable Export Button",
    "summary": """
        This app helps you hide the Action/print, Create, Delete, Edit, and Export buttons for specific users.
        """,
    "version": "15.0.1",
    "description": """
        This app helps you hide the Action/print, Create, Delete, Edit, and Export buttons for specific users.
        Odoo All in One Hide/Enable Buttons
        Disable Action Button
        Disable Create Button
        Disable Delete Button
        Disable Edit Button
        Disable Export Button
        Disable Print Button
        Hide Action Button
        Hide Create Button
        Hide Delete Button
        Hide Edit Button
        Hide Export Button
        Hide Print Button
        """,    
    "author": "CFIS",
    "maintainer": "CFIS",
    "license" :  "Other proprietary",
    "website": "https://www.cfis.store",
    "images": ["images/disable_create_edit_globally.png"],
    "category": "Web",
    "depends": [
        "base",
        "web",
        "sale",
        "product",
        "account",
        "contacts",
        "purchase",
        "stock"
    ],
    "data": [
        "security/groups.xml",
        "views/hide_button_in_all_view.xml",
    ],
    "assets": {        
        "web.assets_backend": [
            "/disable_create_edit_globally/static/src/js/FormController.js",
            "/disable_create_edit_globally/static/src/js/KanbanController.js",
            "/disable_create_edit_globally/static/src/js/ListController.js",
        ],
        "web.assets_qweb": [      
             
        ],
    },
    "installable": True,
    "application": True,
    "price"                 :  8,
    "currency"              :  "EUR",
    "pre_init_hook"         :  "pre_init_check",
}