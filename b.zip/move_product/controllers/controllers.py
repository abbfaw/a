# -*- coding: utf-8 -*-
# from odoo import http


# class MoveProduct(http.Controller):
#     @http.route('/move_product/move_product/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/move_product/move_product/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('move_product.listing', {
#             'root': '/move_product/move_product',
#             'objects': http.request.env['move_product.move_product'].search([]),
#         })

#     @http.route('/move_product/move_product/objects/<model("move_product.move_product"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('move_product.object', {
#             'object': obj
#         })
