from odoo import api, models, fields


class ProductLine(models.Model):
    _name = 'product.move'

    barcode = fields.Char(string='code barre')
    name = fields.Char(string='name')
    date_inv = fields.Datetime(string='Date Inventaire')
    date_end = fields.Datetime(string='Date fin')
    quantity = fields.Float(string='Quantity')

    def get_no_move_product(self):
        product = self.env['product.product'].search([])
        ids = product.mapped('id')
        move_line = self.env['stock.move.line'].search([('date', '>', self.date_inv),('date', '<', self.date_end), ('state', '=', 'done')])
        move = move_line.mapped('product_id').mapped('id')
        print('move line ....', move)

        for prod in ids:
            if prod not in move:
                quant = self.env['stock.quant'].search([('product_id', '=', prod)])
                line = self.env['product.product'].search([('id', '=', prod)])
                for qt in quant:
                    if qt.quantity < 0:
                        for li in line:
                            val = {
                                'barcode': li.barcode,
                                'name': li.name,
                                'quantity': qt,
                                'date_inv': li.date
                            }
                            self.env['product.move'].create(val)


